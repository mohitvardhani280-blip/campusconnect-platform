export type UserRole = 'student' | 'faculty' | 'admin';

export type AnnouncementCategory =
  | 'Academics'
  | 'Examinations'
  | 'Events'
  | 'Holidays'
  | 'Placements'
  | 'General';

export type Priority = 'urgent' | 'high' | 'normal';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar: string;
  department: string;
  semester?: number;
  employeeId?: string;
  designation?: string;
}

export interface Announcement {
  id: string;
  title: string;
  summary: string;
  content: string;
  category: AnnouncementCategory;
  priority: Priority;
  publishedBy: string;
  publishedByRole: UserRole;
  publishedDate: string;
  deadline?: string;
  targetDepartments: string[];
  targetSemesters: number[];
  hasAttachment: boolean;
  attachmentName?: string;
  acknowledged?: number;
  totalRecipients?: number;
  tags?: string[];
}

export interface ExamSchedule {
  id: string;
  subject: string;
  code: string;
  date: string;
  time: string;
  duration: string;
  room: string;
  type: 'Mid-Sem' | 'End-Sem' | 'Quiz' | 'Practical';
}

export interface Assignment {
  id: string;
  title: string;
  subject: string;
  dueDate: string;
  status: 'pending' | 'submitted' | 'graded';
  grade?: string;
  description: string;
}

export interface CollegeEvent {
  id: string;
  title: string;
  date: string;
  time: string;
  venue: string;
  category: string;
  description: string;
  organizer: string;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'announcement' | 'deadline' | 'event' | 'reminder';
  timestamp: string;
  read: boolean;
  link?: string;
}

export interface Department {
  id: string;
  name: string;
  code: string;
  hod: string;
  students: number;
  faculty: number;
  semesters: number;
}

export interface ManagedUser {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  department: string;
  semester?: number;
  status: 'active' | 'inactive' | 'pending';
  joinedDate: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  sources?: { title: string; date: string }[];
}

export type ScreenType =
  | 'login'
  | 'dashboard'
  | 'noticeboard'
  | 'calendar'
  | 'notifications'
  | 'faculty-create'
  | 'faculty-my-announcements'
  | 'admin-users'
  | 'admin-departments'
  | 'admin-analytics'
  | 'profile';
