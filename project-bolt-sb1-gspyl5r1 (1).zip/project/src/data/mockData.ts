import type {
  User,
  Announcement,
  ExamSchedule,
  Assignment,
  CollegeEvent,
  Notification,
  Department,
  ManagedUser,
} from '@/types';

export const currentUser: User = {
  id: 'u001',
  name: 'Aarav Sharma',
  email: 'aarav.sharma@nift.edu.in',
  role: 'student',
  avatar: 'AS',
  department: 'Computer Science & Engineering',
  semester: 5,
};

export const facultyUser: User = {
  id: 'u002',
  name: 'Dr. Priya Nair',
  email: 'priya.nair@nift.edu.in',
  role: 'faculty',
  avatar: 'PN',
  department: 'Computer Science & Engineering',
  employeeId: 'EMP-CSE-042',
  designation: 'Associate Professor',
};

export const adminUser: User = {
  id: 'u003',
  name: 'Rajesh Mehta',
  email: 'rajesh.mehta@nift.edu.in',
  role: 'admin',
  avatar: 'RM',
  department: 'Administration',
  employeeId: 'EMP-ADM-001',
  designation: 'Registrar',
};

export const departments: Department[] = [
  { id: 'd1', name: 'Computer Science & Engineering', code: 'CSE', hod: 'Dr. Vikram Reddy', students: 480, faculty: 24, semesters: 8 },
  { id: 'd2', name: 'Electronics & Communication', code: 'ECE', hod: 'Dr. Suresh Kumar', students: 360, faculty: 18, semesters: 8 },
  { id: 'd3', name: 'Mechanical Engineering', code: 'MECH', hod: 'Dr. Anjali Gupta', students: 300, faculty: 15, semesters: 8 },
  { id: 'd4', name: 'Civil Engineering', code: 'CIVIL', hod: 'Dr. Mohan Rao', students: 240, faculty: 12, semesters: 8 },
  { id: 'd5', name: 'Information Technology', code: 'IT', hod: 'Dr. Kavitha Singh', students: 280, faculty: 14, semesters: 8 },
  { id: 'd6', name: 'Business Administration', code: 'MBA', hod: 'Dr. Sanjay Patel', students: 120, faculty: 8, semesters: 4 },
];

export const allDepartments = departments.map((d) => d.name);
export const allCategoryList = ['Academics', 'Examinations', 'Events', 'Holidays', 'Placements', 'General'] as const;

export const announcements: Announcement[] = [
  {
    id: 'a001',
    title: 'Mid-Semester Examinations — Schedule Released',
    summary: 'The mid-semester examination schedule for Fall 2026 has been published. Exams begin October 20.',
    content: 'The mid-semester examinations for the Fall 2026 semester will commence from October 20, 2026. All students are advised to check their individual timetables on the portal. Examinations will be conducted in two sessions: morning (9:00 AM - 12:00 PM) and afternoon (2:00 PM - 5:00 PM). Students must carry their hall tickets and college ID cards. No requests for rescheduling will be entertained after October 15.',
    category: 'Examinations',
    priority: 'urgent',
    publishedBy: 'Examination Cell',
    publishedByRole: 'admin',
    publishedDate: '2026-10-08T09:00:00',
    deadline: '2026-10-20',
    targetDepartments: ['Computer Science & Engineering', 'Electronics & Communication', 'Mechanical Engineering', 'Civil Engineering', 'Information Technology'],
    targetSemesters: [3, 5, 7],
    hasAttachment: true,
    attachmentName: 'Mid-Sem_Schedule_Fall2026.pdf',
    acknowledged: 342,
    totalRecipients: 870,
    tags: ['Fall 2026', 'Mid-Sem', 'Important'],
  },
  {
    id: 'a002',
    title: 'Campus Placement Drive — TCS & Infosys',
    summary: 'TCS and Infosys are conducting a joint campus placement drive on October 25 for final-year students.',
    content: 'Tata Consultancy Services (TCS) and Infosys will be conducting a joint campus placement drive on October 25, 2026, at the Main Auditorium. The drive is open to all final-year students (7th and 8th semester) from CSE, IT, and ECE departments. Eligibility criteria: minimum 6.5 CGPA, no active backlogs. The selection process includes an online aptitude test, technical interview, and HR interview. Students must register on the placement portal by October 22.',
    category: 'Placements',
    priority: 'high',
    publishedBy: 'Training & Placement Cell',
    publishedByRole: 'admin',
    publishedDate: '2026-10-07T14:30:00',
    deadline: '2026-10-22',
    targetDepartments: ['Computer Science & Engineering', 'Information Technology', 'Electronics & Communication'],
    targetSemesters: [7, 8],
    hasAttachment: true,
    attachmentName: 'Placement_Drive_Details.pdf',
    acknowledged: 156,
    totalRecipients: 210,
    tags: ['Placement', 'TCS', 'Infosys', 'Final Year'],
  },
  {
    id: 'a003',
    title: 'Technical Symposium — InnovateX 2026',
    summary: 'Annual technical symposium featuring hackathons, paper presentations, and guest speakers on October 28-29.',
    content: 'The Department of Computer Science & Engineering is proud to present InnovateX 2026, our flagship technical symposium. The two-day event features a 24-hour hackathon, paper presentation competition, technical quiz, and keynote speeches from industry leaders at Google and Microsoft. Cash prizes worth Rs. 50,000. Registration fee: Rs. 200 per student. Last date to register: October 24.',
    category: 'Events',
    priority: 'normal',
    publishedBy: 'Dr. Priya Nair',
    publishedByRole: 'faculty',
    publishedDate: '2026-10-06T11:00:00',
    deadline: '2026-10-24',
    targetDepartments: ['Computer Science & Engineering', 'Information Technology', 'Electronics & Communication'],
    targetSemesters: [1, 2, 3, 4, 5, 6, 7, 8],
    hasAttachment: false,
    acknowledged: 89,
    totalRecipients: 320,
    tags: ['Symposium', 'Hackathon', 'CSE'],
  },
  {
    id: 'a004',
    title: 'Assignment Submission — Database Management Systems',
    summary: 'DBMS Assignment 3 on Normalization and Transaction Management is due on October 18.',
    content: 'All students of 5th semester CSE are required to submit Assignment 3 for Database Management Systems (BCCS-501). The assignment covers Chapters 5 and 6: Normalization (1NF through BCNF) and Transaction Management & Concurrency Control. Submit a hard copy to the faculty cabin (Room 214, CSE Block) before 4:00 PM on October 18. Late submissions will not be accepted.',
    category: 'Academics',
    priority: 'high',
    publishedBy: 'Dr. Priya Nair',
    publishedByRole: 'faculty',
    publishedDate: '2026-10-05T10:15:00',
    deadline: '2026-10-18',
    targetDepartments: ['Computer Science & Engineering'],
    targetSemesters: [5],
    hasAttachment: true,
    attachmentName: 'DBMS_Assignment3.pdf',
    acknowledged: 72,
    totalRecipients: 120,
    tags: ['DBMS', 'Assignment', 'CSE-5'],
  },
  {
    id: 'a005',
    title: 'Diwali Break — College Holiday Notice',
    summary: 'The college will remain closed from October 31 to November 3 for Diwali celebrations.',
    content: 'In view of the Diwali festival, the college will remain closed from October 31, 2026 to November 3, 2026 (both days inclusive). Regular classes will resume on November 4, 2026. All laboratory sessions scheduled during this period are cancelled and will be rescheduled. The library will remain open with reduced hours (10:00 AM to 2:00 PM) on October 30 and November 4.',
    category: 'Holidays',
    priority: 'normal',
    publishedBy: 'Administration Office',
    publishedByRole: 'admin',
    publishedDate: '2026-10-04T16:00:00',
    targetDepartments: allDepartments,
    targetSemesters: [1, 2, 3, 4, 5, 6, 7, 8],
    hasAttachment: false,
    acknowledged: 780,
    totalRecipients: 1780,
    tags: ['Diwali', 'Holiday'],
  },
  {
    id: 'a006',
    title: 'Library Timing Extended During Exam Week',
    summary: 'Library will remain open till 10 PM from October 15 to October 25 to support exam preparation.',
    content: 'To support students during the mid-semester examination period, the central library will extend its operating hours. From October 15 to October 25, 2026, the library will remain open from 8:00 AM to 10:00 PM on all days including weekends. Reading hall capacity has been increased with additional seating arranged on the first floor. Digital resources and e-books can be accessed 24/7 through the library portal.',
    category: 'General',
    priority: 'normal',
    publishedBy: 'Library Administration',
    publishedByRole: 'admin',
    publishedDate: '2026-10-03T12:00:00',
    targetDepartments: allDepartments,
    targetSemesters: [1, 2, 3, 4, 5, 6, 7, 8],
    hasAttachment: false,
    acknowledged: 234,
    totalRecipients: 1780,
    tags: ['Library', 'Exam Week'],
  },
  {
    id: 'a007',
    title: 'Guest Lecture — AI & Machine Learning in Industry',
    summary: 'Dr. Arjun Krishnan from Google AI will deliver a guest lecture on October 22 at the Main Auditorium.',
    content: 'The Department of Information Technology is organizing a guest lecture by Dr. Arjun Krishnan, Senior Research Scientist at Google AI. The lecture titled "Large Language Models and the Future of Search" will cover recent advances in NLP, transformer architectures, and real-world deployment challenges. The session is open to all students and faculty. Date: October 22, 2026. Time: 3:00 PM. Venue: Main Auditorium.',
    category: 'Events',
    priority: 'normal',
    publishedBy: 'Dr. Kavitha Singh',
    publishedByRole: 'faculty',
    publishedDate: '2026-10-02T09:30:00',
    deadline: '2026-10-22',
    targetDepartments: ['Computer Science & Engineering', 'Information Technology', 'Electronics & Communication'],
    targetSemesters: [1, 2, 3, 4, 5, 6, 7, 8],
    hasAttachment: false,
    acknowledged: 145,
    totalRecipients: 560,
    tags: ['Guest Lecture', 'AI', 'Google'],
  },
  {
    id: 'a008',
    title: 'Industry Visit — ISRO Satellite Centre',
    summary: 'Industrial visit to ISRO Satellite Centre Bangalore scheduled for November 5. Register by October 20.',
    content: 'The Electronics & Communication Department is organizing an industrial visit to the ISRO Satellite Centre, Bangalore on November 5, 2026. This is a unique opportunity to witness satellite assembly, integration, and testing facilities. The visit is open to 5th and 7th semester ECE students. Registration fee: Rs. 500 (includes transportation and lunch). Limited to 40 seats on a first-come-first-served basis. Register through the department portal.',
    category: 'Events',
    priority: 'high',
    publishedBy: 'Dr. Suresh Kumar',
    publishedByRole: 'faculty',
    publishedDate: '2026-10-01T15:00:00',
    deadline: '2026-10-20',
    targetDepartments: ['Electronics & Communication'],
    targetSemesters: [5, 7],
    hasAttachment: true,
    attachmentName: 'ISRO_Visit_Itinerary.pdf',
    acknowledged: 67,
    totalRecipients: 90,
    tags: ['Industry Visit', 'ISRO', 'ECE'],
  },
  {
    id: 'a009',
    title: 'Scholarship Applications Open — Merit-cum-Means 2026-27',
    summary: 'Applications for Merit-cum-Means scholarship are now open. Last date to apply: November 10.',
    content: 'The college is now accepting applications for the Merit-cum-Means Scholarship for the academic year 2026-27. Eligibility: family income below Rs. 4.5 lakh per annum, minimum 7.0 CGPA in the previous semester. Scholarship covers up to 50% of tuition fees. Students must submit the application form along with income certificate and previous semester mark sheet to the Scholarship Section (Admin Block, Room 105) by November 10, 2026.',
    category: 'Academics',
    priority: 'high',
    publishedBy: 'Scholarship Section',
    publishedByRole: 'admin',
    publishedDate: '2026-09-30T11:30:00',
    deadline: '2026-11-10',
    targetDepartments: allDepartments,
    targetSemesters: [1, 2, 3, 4, 5, 6, 7, 8],
    hasAttachment: true,
    attachmentName: 'Scholarship_Application_Form.pdf',
    acknowledged: 312,
    totalRecipients: 1780,
    tags: ['Scholarship', 'Financial Aid'],
  },
  {
    id: 'a010',
    title: 'Sports Day Registration — Annual Athletics Meet',
    summary: 'Register for the Annual Athletics Meet scheduled for November 15. Events include track, field, and team sports.',
    content: 'The Physical Education Department invites all students to participate in the Annual Athletics Meet on November 15, 2026. Events include 100m, 200m, 400m, 800m, 1500m races, long jump, high jump, shot put, and team events like cricket, football, and volleyball. Registration is free. Winners will receive medals and certificates. Best athlete (male and female) will receive a rolling trophy. Register through the sports portal by November 8.',
    category: 'Events',
    priority: 'normal',
    publishedBy: 'Physical Education Dept',
    publishedByRole: 'faculty',
    publishedDate: '2026-09-28T10:00:00',
    deadline: '2026-11-08',
    targetDepartments: allDepartments,
    targetSemesters: [1, 2, 3, 4, 5, 6, 7, 8],
    hasAttachment: false,
    acknowledged: 198,
    totalRecipients: 1780,
    tags: ['Sports', 'Athletics', 'Annual Meet'],
  },
  {
    id: 'a011',
    title: 'Remedial Classes for Mathematics-II',
    summary: 'Remedial classes for Mathematics-II will be conducted from October 16 in Room 101, Maths Block.',
    content: 'Special remedial classes for Mathematics-II (BCCS-102) will be conducted for students who scored below 50% in the internal assessment. Classes will be held in Room 101, Mathematics Block from October 16 to October 26, every day from 4:00 PM to 5:30 PM. Attendance is mandatory for identified students. The classes will cover Calculus, Linear Algebra, and Differential Equations with problem-solving sessions.',
    category: 'Academics',
    priority: 'normal',
    publishedBy: 'Dr. Vikram Reddy',
    publishedByRole: 'faculty',
    publishedDate: '2026-09-27T14:00:00',
    deadline: '2026-10-26',
    targetDepartments: ['Computer Science & Engineering', 'Information Technology'],
    targetSemesters: [1, 2],
    hasAttachment: false,
    acknowledged: 45,
    totalRecipients: 60,
    tags: ['Remedial', 'Mathematics'],
  },
  {
    id: 'a012',
    title: 'Campus Wi-Fi Maintenance Notice',
    summary: 'Campus Wi-Fi will be unavailable on October 14 from 1 AM to 5 AM due to scheduled maintenance.',
    content: 'The IT Services team will be performing scheduled maintenance on the campus Wi-Fi network on October 14, 2026, from 1:00 AM to 5:00 AM. During this period, internet access across the campus will be unavailable. Wired connections in faculty cabins and labs will remain operational. We apologize for the inconvenience. For urgent connectivity needs, please use the computer lab in the Central Library.',
    category: 'General',
    priority: 'normal',
    publishedBy: 'IT Services',
    publishedByRole: 'admin',
    publishedDate: '2026-09-26T17:30:00',
    targetDepartments: allDepartments,
    targetSemesters: [1, 2, 3, 4, 5, 6, 7, 8],
    hasAttachment: false,
    acknowledged: 0,
    totalRecipients: 1780,
    tags: ['Wi-Fi', 'Maintenance', 'IT'],
  },
];

export const examSchedule: ExamSchedule[] = [
  { id: 'e1', subject: 'Database Management Systems', code: 'BCCS-501', date: '2026-10-20', time: '9:00 AM', duration: '3 hours', room: 'Exam Hall A-201', type: 'Mid-Sem' },
  { id: 'e2', subject: 'Operating Systems', code: 'BCCS-502', date: '2026-10-22', time: '9:00 AM', duration: '3 hours', room: 'Exam Hall A-201', type: 'Mid-Sem' },
  { id: 'e3', subject: 'Computer Networks', code: 'BCCS-503', date: '2026-10-24', time: '9:00 AM', duration: '3 hours', room: 'Exam Hall A-203', type: 'Mid-Sem' },
  { id: 'e4', subject: 'Software Engineering', code: 'BCCS-504', date: '2026-10-26', time: '2:00 PM', duration: '3 hours', room: 'Exam Hall A-202', type: 'Mid-Sem' },
  { id: 'e5', subject: 'Theory of Computation', code: 'BCCS-505', date: '2026-10-28', time: '2:00 PM', duration: '3 hours', room: 'Exam Hall A-202', type: 'Mid-Sem' },
];

export const assignments: Assignment[] = [
  { id: 'as1', title: 'Assignment 3 — Normalization & Transactions', subject: 'DBMS (BCCS-501)', dueDate: '2026-10-18', status: 'pending', description: 'Submit a hard copy to Room 214, CSE Block before 4 PM.' },
  { id: 'as2', title: 'Lab Report — Process Scheduling Algorithms', subject: 'Operating Systems (BCCS-502)', dueDate: '2026-10-17', status: 'pending', description: 'Implement FCFS, SJF, and Round Robin. Submit report and code.' },
  { id: 'as3', title: 'Case Study — TCP vs UDP Analysis', subject: 'Computer Networks (BCCS-503)', dueDate: '2026-10-21', status: 'pending', description: 'Write a 5-page case study comparing TCP and UDP use cases.' },
  { id: 'as4', title: 'Mini Project — Agile Sprint Plan', subject: 'Software Engineering (BCCS-504)', dueDate: '2026-10-15', status: 'submitted', description: 'Create a 2-week sprint plan with user stories and tasks.' },
  { id: 'as5', title: 'Assignment 2 — DFA to Regular Expression', subject: 'Theory of Computation (BCCS-505)', dueDate: '2026-10-02', status: 'graded', grade: 'A', description: 'Convert given DFAs to regular expressions using Arden\'s lemma.' },
];

export const events: CollegeEvent[] = [
  { id: 'ev1', title: 'Mid-Sem Exam — DBMS', date: '2026-10-20', time: '9:00 AM', venue: 'Exam Hall A-201', category: 'Exam', description: 'Mid-semester examination for Database Management Systems.', organizer: 'Examination Cell' },
  { id: 'ev2', title: 'Mid-Sem Exam — Operating Systems', date: '2026-10-22', time: '9:00 AM', venue: 'Exam Hall A-201', category: 'Exam', description: 'Mid-semester examination for Operating Systems.', organizer: 'Examination Cell' },
  { id: 'ev3', title: 'Guest Lecture — AI & ML in Industry', date: '2026-10-22', time: '3:00 PM', venue: 'Main Auditorium', category: 'Lecture', description: 'Dr. Arjun Krishnan from Google AI on LLMs and the future of search.', organizer: 'IT Department' },
  { id: 'ev4', title: 'Placement Drive — TCS & Infosys', date: '2026-10-25', time: '9:00 AM', venue: 'Main Auditorium', category: 'Placement', description: 'Joint campus placement drive for final-year students.', organizer: 'T&P Cell' },
  { id: 'ev5', title: 'InnovateX 2026 Symposium', date: '2026-10-28', time: '9:00 AM', venue: 'CSE Block', category: 'Symposium', description: 'Annual technical symposium with hackathon, paper presentations.', organizer: 'CSE Department' },
  { id: 'ev6', title: 'Diwali Break Begins', date: '2026-10-31', time: 'All Day', venue: 'Campus-wide', category: 'Holiday', description: 'College closed for Diwali festival.', organizer: 'Administration' },
  { id: 'ev7', title: 'Industry Visit — ISRO', date: '2026-11-05', time: '7:00 AM', venue: 'ISRO Bangalore', category: 'Visit', description: 'Industrial visit to ISRO Satellite Centre for ECE students.', organizer: 'ECE Department' },
  { id: 'ev8', title: 'Annual Athletics Meet', date: '2026-11-15', time: '8:00 AM', venue: 'Sports Ground', category: 'Sports', description: 'Annual athletics meet with track, field, and team events.', organizer: 'Physical Education Dept' },
];

export const notifications: Notification[] = [
  { id: 'n1', title: 'Urgent: Mid-Sem Exam Schedule Released', message: 'Examination Cell has published the mid-semester exam schedule. Exams begin October 20.', type: 'announcement', timestamp: '2026-10-08T09:05:00', read: false, link: 'a001' },
  { id: 'n2', title: 'DBMS Assignment Due in 10 Days', message: 'Assignment 3 on Normalization and Transactions is due on October 18.', type: 'deadline', timestamp: '2026-10-08T08:00:00', read: false, link: 'a004' },
  { id: 'n3', title: 'Placement Drive Registration Closing', message: 'TCS & Infosys placement drive — register by October 22.', type: 'reminder', timestamp: '2026-10-07T15:00:00', read: false, link: 'a002' },
  { id: 'n4', title: 'New Event: InnovateX 2026', message: 'Annual technical symposium on October 28-29. Register by October 24.', type: 'event', timestamp: '2026-10-06T11:10:00', read: true, link: 'a003' },
  { id: 'n5', title: 'Guest Lecture on AI & ML', message: 'Dr. Arjun Krishnan from Google AI on October 22 at 3 PM.', type: 'event', timestamp: '2026-10-02T09:35:00', read: true, link: 'a007' },
  { id: 'n6', title: 'Scholarship Applications Open', message: 'Merit-cum-Means scholarship applications due November 10.', type: 'announcement', timestamp: '2026-09-30T11:35:00', read: true, link: 'a009' },
  { id: 'n7', title: 'Diwali Break Notice', message: 'College closed from October 31 to November 3 for Diwali.', type: 'announcement', timestamp: '2026-10-04T16:05:00', read: true, link: 'a005' },
];

export const managedUsers: ManagedUser[] = [
  { id: 'mu1', name: 'Aarav Sharma', email: 'aarav.sharma@nift.edu.in', role: 'student', department: 'CSE', semester: 5, status: 'active', joinedDate: '2023-08-01' },
  { id: 'mu2', name: 'Sneha Reddy', email: 'sneha.reddy@nift.edu.in', role: 'student', department: 'CSE', semester: 5, status: 'active', joinedDate: '2023-08-01' },
  { id: 'mu3', name: 'Karthik Iyer', email: 'karthik.iyer@nift.edu.in', role: 'student', department: 'ECE', semester: 7, status: 'active', joinedDate: '2022-08-01' },
  { id: 'mu4', name: 'Ananya Das', email: 'ananya.das@nift.edu.in', role: 'student', department: 'IT', semester: 3, status: 'active', joinedDate: '2024-08-01' },
  { id: 'mu5', name: 'Rohit Verma', email: 'rohit.verma@nift.edu.in', role: 'student', department: 'MECH', semester: 5, status: 'inactive', joinedDate: '2023-08-01' },
  { id: 'mu6', name: 'Dr. Priya Nair', email: 'priya.nair@nift.edu.in', role: 'faculty', department: 'CSE', status: 'active', joinedDate: '2018-07-15' },
  { id: 'mu7', name: 'Dr. Suresh Kumar', email: 'suresh.kumar@nift.edu.in', role: 'faculty', department: 'ECE', status: 'active', joinedDate: '2016-06-20' },
  { id: 'mu8', name: 'Dr. Kavitha Singh', email: 'kavitha.singh@nift.edu.in', role: 'faculty', department: 'IT', status: 'active', joinedDate: '2019-01-10' },
  { id: 'mu9', name: 'Prof. Arjun Mehta', email: 'arjun.mehta@nift.edu.in', role: 'faculty', department: 'MECH', status: 'pending', joinedDate: '2026-10-01' },
  { id: 'mu10', name: 'Rajesh Mehta', email: 'rajesh.mehta@nift.edu.in', role: 'admin', department: 'Administration', status: 'active', joinedDate: '2015-04-01' },
  { id: 'mu11', name: 'Divya Patel', email: 'divya.patel@nift.edu.in', role: 'student', department: 'CIVIL', semester: 7, status: 'active', joinedDate: '2022-08-01' },
  { id: 'mu12', name: 'Vikram Joshi', email: 'vikram.joshi@nift.edu.in', role: 'student', department: 'CSE', semester: 3, status: 'pending', joinedDate: '2026-10-05' },
];

export const facultyAnnouncements: Announcement[] = announcements.filter(
  (a) => a.publishedByRole === 'faculty'
);

export const formatDate = (dateStr: string): string => {
  const date = new Date(dateStr);
  return date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
};

export const formatTime = (dateStr: string): string => {
  const date = new Date(dateStr);
  return date.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
};

export const formatRelativeTime = (dateStr: string): string => {
  const date = new Date(dateStr);
  const now = new Date('2026-10-09T12:00:00');
  const diffMs = now.getTime() - date.getTime();
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  const diffDays = Math.floor(diffHours / 24);

  if (diffHours < 1) return 'Just now';
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7) return `${diffDays}d ago`;
  return formatDate(dateStr);
};

export const daysUntil = (dateStr: string): number => {
  const target = new Date(dateStr);
  const now = new Date('2026-10-09T00:00:00');
  return Math.ceil((target.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
};
