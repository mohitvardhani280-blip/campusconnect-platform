import { useState, useRef, useEffect } from 'react';
import { useApp } from '@/context/AppContext';
import { Search, Bell, Menu, ChevronDown, LogOut, User as UserIcon, Settings, Repeat } from 'lucide-react';
import type { UserRole } from '@/types';
import { formatRelativeTime } from '@/data/mockData';

export default function TopBar() {
  const { user, role, toggleSidebar, notifications, unreadCount, markNotificationRead, markAllNotificationsRead, setScreen, logout, setRole } = useApp();
  const [showNotifs, setShowNotifs] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showRoleSwitch, setShowRoleSwitch] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);
  const roleRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) setShowNotifs(false);
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) setShowProfile(false);
      if (roleRef.current && !roleRef.current.contains(e.target as Node)) setShowRoleSwitch(false);
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const roles: { value: UserRole; label: string }[] = [
    { value: 'student', label: 'Student' },
    { value: 'faculty', label: 'Faculty' },
    { value: 'admin', label: 'Admin' },
  ];

  return (
    <header className="sticky top-0 z-20 bg-white border-b border-navy-100 h-16 flex items-center px-4 gap-3">
      {/* Mobile menu */}
      <button onClick={toggleSidebar} className="lg:hidden btn-ghost !p-2">
        <Menu className="w-5 h-5" />
      </button>

      {/* Search bar */}
      <div className="flex-1 max-w-xl relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-navy-400" />
        <input
          type="text"
          placeholder="Search announcements, exams, events..."
          className="w-full pl-10 pr-4 py-2 bg-navy-50 border border-transparent rounded-lg text-sm text-navy-900 placeholder:text-navy-400 transition-all focus:outline-none focus:bg-white focus:border-navy-200 focus:ring-2 focus:ring-primary-500/20"
        />
      </div>

      {/* Role switcher (demo) */}
      <div className="relative" ref={roleRef}>
        <button
          onClick={() => setShowRoleSwitch(!showRoleSwitch)}
          className="hidden sm:flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-navy-600 hover:bg-navy-100 transition-colors"
        >
          <Repeat className="w-4 h-4" />
          <span className="font-medium capitalize">{role}</span>
          <ChevronDown className="w-3.5 h-3.5" />
        </button>
        {showRoleSwitch && (
          <div className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-navy-100 py-1.5 animate-slide-up z-30">
            <p className="px-3 py-1.5 text-xs font-medium text-navy-400 uppercase tracking-wide">Switch Role (Demo)</p>
            {roles.map((r) => (
              <button
                key={r.value}
                onClick={() => {
                  setRole(r.value);
                  setShowRoleSwitch(false);
                }}
                className={`w-full text-left px-3 py-2 text-sm flex items-center gap-2 transition-colors ${
                  role === r.value ? 'bg-primary-50 text-primary-700 font-semibold' : 'text-navy-700 hover:bg-navy-50'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-current opacity-50" />
                {r.label} View
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Notifications */}
      <div className="relative" ref={notifRef}>
        <button
          onClick={() => setShowNotifs(!showNotifs)}
          className="relative btn-ghost !p-2"
        >
          <Bell className="w-5 h-5" />
          {unreadCount > 0 && (
            <span className="absolute top-1 right-1 bg-danger-500 text-white text-xs font-bold rounded-full min-w-[18px] h-[18px] flex items-center justify-center px-1">
              {unreadCount}
            </span>
          )}
        </button>
        {showNotifs && (
          <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-xl shadow-xl border border-navy-100 animate-slide-up z-30 max-h-[70vh] overflow-hidden flex flex-col">
            <div className="flex items-center justify-between px-4 py-3 border-b border-navy-100">
              <h3 className="font-semibold text-navy-900">Notifications</h3>
              {unreadCount > 0 && (
                <button onClick={markAllNotificationsRead} className="text-xs text-primary-600 font-medium hover:text-primary-700">
                  Mark all read
                </button>
              )}
            </div>
            <div className="overflow-y-auto flex-1">
              {notifications.length === 0 ? (
                <div className="p-8 text-center text-navy-400 text-sm">No notifications</div>
              ) : (
                notifications.slice(0, 8).map((n) => (
                  <button
                    key={n.id}
                    onClick={() => {
                      markNotificationRead(n.id);
                      setScreen('notifications');
                      setShowNotifs(false);
                    }}
                    className={`w-full text-left px-4 py-3 border-b border-navy-50 hover:bg-navy-50 transition-colors flex gap-3 ${!n.read ? 'bg-primary-50/40' : ''}`}
                  >
                    <div className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${n.read ? 'bg-navy-200' : 'bg-primary-500'}`} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-navy-800 leading-tight">{n.title}</p>
                      <p className="text-xs text-navy-500 mt-0.5 line-clamp-2">{n.message}</p>
                      <p className="text-xs text-navy-400 mt-1">{formatRelativeTime(n.timestamp)}</p>
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>
        )}
      </div>

      {/* Profile menu */}
      <div className="relative" ref={profileRef}>
        <button
          onClick={() => setShowProfile(!showProfile)}
          className="flex items-center gap-2 p-1 pr-2 rounded-lg hover:bg-navy-100 transition-colors"
        >
          <div className="w-8 h-8 rounded-full bg-primary-600 text-white text-xs font-bold flex items-center justify-center">
            {user.avatar}
          </div>
          <ChevronDown className="w-4 h-4 text-navy-500 hidden sm:block" />
        </button>
        {showProfile && (
          <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-navy-100 py-1.5 animate-slide-up z-30">
            <div className="px-3 py-2 border-b border-navy-100">
              <p className="text-sm font-semibold text-navy-900">{user.name}</p>
              <p className="text-xs text-navy-500">{user.email}</p>
              <p className="text-xs text-primary-600 font-medium mt-1 capitalize">{role} • {user.department}</p>
            </div>
            <button className="w-full text-left px-3 py-2 text-sm text-navy-700 hover:bg-navy-50 flex items-center gap-2">
              <UserIcon className="w-4 h-4" /> My Profile
            </button>
            <button className="w-full text-left px-3 py-2 text-sm text-navy-700 hover:bg-navy-50 flex items-center gap-2">
              <Settings className="w-4 h-4" /> Settings
            </button>
            <div className="border-t border-navy-100 mt-1 pt-1">
              <button onClick={logout} className="w-full text-left px-3 py-2 text-sm text-danger-600 hover:bg-danger-50 flex items-center gap-2">
                <LogOut className="w-4 h-4" /> Sign Out
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
