import { useApp } from '@/context/AppContext';
import type { ScreenType, UserRole } from '@/types';
import {
  LayoutDashboard,
  ClipboardList,
  CalendarDays,
  Bell,
  Megaphone,
  FilePlus2,
  Users,
  Building2,
  BarChart3,
  GraduationCap,
  LogOut,
  X,
  Sparkles,
} from 'lucide-react';

interface NavItem {
  screen: ScreenType;
  label: string;
  icon: typeof LayoutDashboard;
  roles: UserRole[];
}

const navItems: NavItem[] = [
  { screen: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['student', 'faculty', 'admin'] },
  { screen: 'noticeboard', label: 'Notice Board', icon: ClipboardList, roles: ['student', 'faculty', 'admin'] },
  { screen: 'calendar', label: 'Calendar', icon: CalendarDays, roles: ['student', 'faculty', 'admin'] },
  { screen: 'notifications', label: 'Notifications', icon: Bell, roles: ['student', 'faculty', 'admin'] },
  { screen: 'faculty-create', label: 'Create Announcement', icon: FilePlus2, roles: ['faculty'] },
  { screen: 'faculty-my-announcements', label: 'My Announcements', icon: Megaphone, roles: ['faculty'] },
  { screen: 'admin-users', label: 'User Management', icon: Users, roles: ['admin'] },
  { screen: 'admin-departments', label: 'Departments', icon: Building2, roles: ['admin'] },
  { screen: 'admin-analytics', label: 'Analytics', icon: BarChart3, roles: ['admin'] },
];

export default function Sidebar() {
  const { user, role, screen, setScreen, logout, sidebarOpen, setSidebarOpen, unreadCount } = useApp();

  const filteredItems = navItems.filter((item) => item.roles.includes(role));

  const handleNav = (s: ScreenType) => {
    setScreen(s);
    setSidebarOpen(false);
  };

  return (
    <>
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-navy-950/50 z-30 lg:hidden animate-fade-in"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <aside
        className={`fixed lg:sticky top-0 left-0 h-screen w-64 bg-navy-900 text-white flex flex-col z-40 transition-transform duration-300 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Logo */}
        <div className="flex items-center justify-between px-4 py-4 border-b border-navy-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 bg-primary-600 rounded-lg flex items-center justify-center flex-shrink-0">
              <GraduationCap className="w-5 h-5 text-white" />
            </div>
            <div className="min-w-0">
              <h1 className="text-sm font-bold leading-tight">CampusConnect</h1>
              <p className="text-xs text-navy-400 leading-tight">AI Platform</p>
            </div>
          </div>
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden text-navy-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Role badge */}
        <div className="px-3 py-3">
          <div className="flex items-center gap-2 px-3 py-2 bg-navy-800 rounded-lg">
            <Sparkles className="w-4 h-4 text-primary-400 flex-shrink-0" />
            <div className="text-xs">
              <span className="text-navy-300">Signed in as </span>
              <span className="font-semibold text-white capitalize">{role}</span>
            </div>
          </div>
        </div>

        {/* Nav items */}
        <nav className="flex-1 overflow-y-auto px-3 pb-3 space-y-0.5">
          {filteredItems.map((item) => {
            const Icon = item.icon;
            const isActive = screen === item.screen;
            return (
              <button
                key={item.screen}
                onClick={() => handleNav(item.screen)}
                className={`nav-item w-full ${isActive ? 'nav-item-active' : ''}`}
              >
                <Icon className="w-5 h-5 flex-shrink-0" />
                <span className="text-sm">{item.label}</span>
                {item.screen === 'notifications' && unreadCount > 0 && (
                  <span className="ml-auto bg-danger-500 text-white text-xs font-bold rounded-full px-1.5 py-0.5 min-w-[20px] text-center">
                    {unreadCount}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* User & logout */}
        <div className="px-3 py-3 border-t border-navy-800">
          <div className="flex items-center gap-2.5 px-2 py-2 mb-2">
            <div className="w-8 h-8 rounded-full bg-primary-600 text-white text-xs font-bold flex items-center justify-center flex-shrink-0">
              {user.avatar}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium truncate">{user.name}</p>
              <p className="text-xs text-navy-400 truncate">{user.email}</p>
            </div>
          </div>
          <button onClick={logout} className="nav-item w-full text-navy-400 hover:text-danger-400 hover:bg-danger-500/10">
            <LogOut className="w-5 h-5" />
            <span className="text-sm">Sign Out</span>
          </button>
        </div>
      </aside>
    </>
  );
}
