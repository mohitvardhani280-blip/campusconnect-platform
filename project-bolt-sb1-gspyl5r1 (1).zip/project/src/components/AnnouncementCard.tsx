import { useApp } from '@/context/AppContext';
import { formatRelativeTime, formatDate, daysUntil } from '@/data/mockData';
import { priorityConfig, categoryConfig, getDaysLabel } from '@/lib/uiConfig';
import type { Announcement } from '@/types';
import {
  FileText,
  CalendarDays,
  Briefcase,
  Palmtree,
  BookOpen,
  Info,
  Paperclip,
  AlertTriangle,
  Clock,
  CheckCircle2,
  Users,
} from 'lucide-react';

const iconMap: Record<string, typeof FileText> = {
  FileText,
  CalendarDays,
  Briefcase,
  Palmtree,
  BookOpen,
  Info,
};

export default function AnnouncementCard({ announcement, compact = false }: { announcement: Announcement; compact?: boolean }) {
  const { selectAnnouncement, setScreen } = useApp();
  const cat = categoryConfig[announcement.category];
  const pri = priorityConfig[announcement.priority];
  const Icon = iconMap[cat.icon] || Info;
  const ackRate = announcement.totalRecipients
    ? Math.round((announcement.acknowledged ?? 0) / announcement.totalRecipients * 100)
    : 0;
  const daysLeft = announcement.deadline ? daysUntil(announcement.deadline) : null;

  const handleClick = () => {
    selectAnnouncement(announcement.id);
    setScreen('noticeboard');
  };

  if (compact) {
    return (
      <div
        onClick={handleClick}
        className="card-hover cursor-pointer p-3.5 group"
      >
        <div className="flex items-start gap-3">
          <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${cat.classes}`}>
            <Icon className="w-4.5 h-4.5" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-0.5">
              <span className={`w-2 h-2 rounded-full ${pri.dot} flex-shrink-0`} />
              <h4 className="text-sm font-semibold text-navy-800 truncate group-hover:text-primary-700 transition-colors">{announcement.title}</h4>
            </div>
            <p className="text-xs text-navy-500 line-clamp-1">{announcement.summary}</p>
            <div className="flex items-center gap-2 mt-1.5 text-xs text-navy-400">
              <Clock className="w-3 h-3" />
              <span>{formatRelativeTime(announcement.publishedDate)}</span>
              {announcement.deadline && daysLeft !== null && daysLeft >= 0 && (
                <span className={`font-medium ${daysLeft <= 3 ? 'text-danger-600' : 'text-warning-600'}`}>
                  • Due {getDaysLabel(daysLeft)}
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      onClick={handleClick}
      className="card-hover cursor-pointer p-5 group animate-fade-in"
    >
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-center gap-2.5">
          <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${cat.classes}`}>
            <Icon className="w-5 h-5" />
          </div>
          <div>
            <span className={`badge ${cat.classes} mb-1`}>{announcement.category}</span>
            <div className="flex items-center gap-1.5">
              <span className={`w-2 h-2 rounded-full ${pri.dot}`} />
              <span className={`text-xs font-medium ${announcement.priority === 'urgent' ? 'text-danger-600' : announcement.priority === 'high' ? 'text-warning-600' : 'text-navy-500'}`}>
                {pri.label}
              </span>
            </div>
          </div>
        </div>
        {announcement.hasAttachment && (
          <div className="flex items-center gap-1 text-xs text-navy-400">
            <Paperclip className="w-3.5 h-3.5" />
          </div>
        )}
      </div>

      <h3 className="text-base font-bold text-navy-900 mb-1.5 group-hover:text-primary-700 transition-colors leading-snug">
        {announcement.title}
      </h3>
      <p className="text-sm text-navy-600 leading-relaxed mb-3 line-clamp-2">{announcement.summary}</p>

      <div className="flex items-center justify-between pt-3 border-t border-navy-100">
        <div className="flex items-center gap-2 text-xs text-navy-500">
          <span className="font-medium">{announcement.publishedBy}</span>
          <span>•</span>
          <span>{formatRelativeTime(announcement.publishedDate)}</span>
        </div>
        {daysLeft !== null && daysLeft >= 0 ? (
          <span className={`badge ${daysLeft <= 3 ? 'bg-danger-100 text-danger-700' : 'bg-warning-100 text-warning-700'}`}>
            <Clock className="w-3 h-3" />
            {getDaysLabel(daysLeft)}
          </span>
        ) : announcement.totalRecipients ? (
          <span className="flex items-center gap-1 text-xs text-navy-400">
            <Users className="w-3.5 h-3.5" />
            {ackRate}% acknowledged
          </span>
        ) : null}
      </div>
    </div>
  );
}
