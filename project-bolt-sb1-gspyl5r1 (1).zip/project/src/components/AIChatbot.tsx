import { useState, useRef, useEffect } from 'react';
import type { ChatMessage } from '@/types';
import { Sparkles, X, Send, MessageCircle, Bot } from 'lucide-react';
import { announcements, examSchedule, events, formatDate, daysUntil } from '@/data/mockData';

const suggestedQuestions = [
  'When is my next exam?',
  'Show me placement announcements',
  'What events are coming up?',
  'When does the DBMS assignment close?',
  'What are the upcoming deadlines?',
  'Is there a holiday soon?',
];

function generateAIResponse(query: string): { text: string; sources?: { title: string; date: string }[] } {
  const q = query.toLowerCase();

  // Exam-related queries
  if (q.includes('exam') || q.includes('test') || q.includes('mid-sem') || q.includes('midsem')) {
    const upcomingExams = examSchedule.filter((e) => daysUntil(e.date) >= 0).sort((a, b) => a.date.localeCompare(b.date));
    if (upcomingExams.length > 0) {
      const next = upcomingExams[0];
      const d = daysUntil(next.date);
      const examList = upcomingExams.slice(0, 4).map((e) => `• ${e.subject} (${e.code}) — ${formatDate(e.date)} at ${e.time}, ${e.room}`).join('\n');
      return {
        text: `Your next exam is **${next.subject}** (${next.code}) on ${formatDate(next.date)} at ${next.time} in ${next.room}. ${d === 0 ? 'That\'s today!' : d === 1 ? 'That\'s tomorrow!' : `That's in ${d} days.`}\n\nHere's your full mid-sem schedule:\n${examList}`,
        sources: [{ title: 'Mid-Semester Examinations — Schedule Released', date: '2026-10-08' }],
      };
    }
  }

  // Placement queries
  if (q.includes('placement') || q.includes('job') || q.includes('recruit') || q.includes('campus drive') || q.includes('tcs') || q.includes('infosys')) {
    const placementNotices = announcements.filter((a) => a.category === 'Placements');
    if (placementNotices.length > 0) {
      const list = placementNotices.map((a) => `• ${a.title} — Deadline: ${a.deadline ? formatDate(a.deadline) : 'N/A'}`).join('\n');
      return {
        text: `Here are the current placement announcements:\n\n${list}\n\nMake sure to register before the deadlines. The TCS & Infosys joint drive is on October 25 — eligibility requires 6.5+ CGPA and no active backlogs.`,
        sources: [{ title: 'Campus Placement Drive — TCS & Infosys', date: '2026-10-07' }],
      };
    }
  }

  // Event queries
  if (q.includes('event') || q.includes('symposium') || q.includes('lecture') || q.includes('sports') || q.includes('visit')) {
    const upcoming = events.filter((e) => daysUntil(e.date) >= 0).slice(0, 5);
    if (upcoming.length > 0) {
      const list = upcoming.map((e) => `• ${e.title} — ${formatDate(e.date)} at ${e.time}, ${e.venue}`).join('\n');
      return {
        text: `Here are the upcoming events:\n\n${list}\n\nThe InnovateX 2026 symposium on Oct 28-29 features a 24-hour hackathon with Rs. 50,000 in prizes. Registration closes October 24.`,
        sources: [
          { title: 'Technical Symposium — InnovateX 2026', date: '2026-10-06' },
          { title: 'Guest Lecture — AI & Machine Learning in Industry', date: '2026-10-02' },
        ],
      };
    }
  }

  // Assignment/deadline queries
  if (q.includes('assignment') || q.includes('deadline') || q.includes('due') || q.includes('submit')) {
    const deadlineNotices = announcements.filter((a) => a.deadline && daysUntil(a.deadline) >= 0).sort((a, b) => (a.deadline! < b.deadline! ? -1 : 1));
    if (deadlineNotices.length > 0) {
      const list = deadlineNotices.slice(0, 5).map((a) => `• ${a.title} — Due: ${formatDate(a.deadline!)} (${daysUntil(a.deadline!)} days left)`).join('\n');
      return {
        text: `Here are your upcoming deadlines, sorted by closest first:\n\n${list}\n\nThe most urgent is the OS Lab Report due in ${daysUntil('2026-10-17')} days. Make sure to submit before 4:00 PM.`,
        sources: [
          { title: 'Assignment Submission — Database Management Systems', date: '2026-10-05' },
          { title: 'Mid-Semester Examinations — Schedule Released', date: '2026-10-08' },
        ],
      };
    }
  }

  // Holiday queries
  if (q.includes('holiday') || q.includes('break') || q.includes('closed') || q.includes('diwali') || q.includes('vacation')) {
    return {
      text: `The college will be closed from **October 31 to November 3** for Diwali. Regular classes resume on November 4. The library will have reduced hours (10 AM – 2 PM) on October 30 and November 4.`,
      sources: [{ title: 'Diwali Break — College Holiday Notice', date: '2026-10-04' }],
    };
  }

  // Scholarship queries
  if (q.includes('scholarship') || q.includes('financial') || q.includes('fees') || q.includes('aid')) {
    return {
      text: `The **Merit-cum-Means Scholarship** for 2026-27 is now open. Eligibility: family income below Rs. 4.5 lakh/annum and minimum 7.0 CGPA. It covers up to 50% of tuition fees. Submit your application with income certificate and mark sheet to the Scholarship Section (Admin Block, Room 105) by **November 10**.`,
      sources: [{ title: 'Scholarship Applications Open — Merit-cum-Means 2026-27', date: '2026-09-30' }],
    };
  }

  // Library queries
  if (q.includes('library') || q.includes('book') || q.includes('study')) {
    return {
      text: `The library has extended hours during exam week: **8:00 AM to 10:00 PM** from October 15-25, including weekends. Additional seating is arranged on the first floor. Digital resources and e-books are accessible 24/7 through the library portal.`,
      sources: [{ title: 'Library Timing Extended During Exam Week', date: '2026-10-03' }],
    };
  }

  // General/summarize
  if (q.includes('summary') || q.includes('summarize') || q.includes('overview') || q.includes('what') || q.includes('important')) {
    const urgent = announcements.filter((a) => a.priority === 'urgent');
    const high = announcements.filter((a) => a.priority === 'high');
    return {
      text: `Here's your overview:\n\n**Urgent:** ${urgent.map((a) => a.title).join(', ')}\n\n**High Priority:** ${high.slice(0, 3).map((a) => a.title).join(', ')}\n\nYour next exam is DBMS on October 20. The placement drive registration closes October 22.`,
      sources: [{ title: 'Mid-Semester Examinations — Schedule Released', date: '2026-10-08' }],
    };
  }

  // Fallback
  return {
    text: `I couldn't find specific information about that in the official college notices. I can help with exam schedules, placement announcements, events, assignment deadlines, holidays, scholarships, and library timings. Try asking something like "When is my next exam?" or "Show me placement announcements."`,
  };
}

export default function AIChatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'm0',
      sender: 'ai',
      text: "Hi! I'm your CampusConnect AI assistant. I can answer questions about official college notices, exam dates, deadlines, and events. How can I help you?",
      timestamp: new Date().toISOString(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleSend = (text?: string) => {
    const query = text || input.trim();
    if (!query) return;

    const userMsg: ChatMessage = {
      id: `m${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    setTimeout(() => {
      const response = generateAIResponse(query);
      const aiMsg: ChatMessage = {
        id: `m${Date.now() + 1}`,
        sender: 'ai',
        text: response.text,
        timestamp: new Date().toISOString(),
        sources: response.sources,
      };
      setMessages((prev) => [...prev, aiMsg]);
      setIsTyping(false);
    }, 800 + Math.random() * 600);
  };

  const renderText = (text: string) => {
    const parts = text.split(/(\*\*[^*]+\*\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={i} className="font-semibold text-navy-900">{part.slice(2, -2)}</strong>;
      }
      return <span key={i}>{part}</span>;
    });
  };

  return (
    <>
      {/* Floating button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-5 right-5 z-40 w-14 h-14 bg-primary-600 text-white rounded-full shadow-lg hover:bg-primary-700 transition-all hover:scale-110 active:scale-95 flex items-center justify-center group"
        >
          <MessageCircle className="w-6 h-6" />
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-accent-500 rounded-full border-2 border-white animate-pulse-soft" />
        </button>
      )}

      {/* Chat window */}
      {isOpen && (
        <div className="fixed bottom-0 right-0 sm:bottom-5 sm:right-5 z-40 w-full sm:w-[400px] h-[85vh] sm:h-[600px] bg-white sm:rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-slide-up sm:border sm:border-navy-100">
          {/* Header */}
          <div className="bg-gradient-to-r from-navy-900 to-navy-800 text-white px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 bg-primary-600 rounded-lg flex items-center justify-center">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-semibold text-sm">CampusConnect AI</h3>
                <p className="text-xs text-navy-300 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-success-500 rounded-full" /> Online — powered by verified data
                </p>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-navy-300 hover:text-white p-1">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3 bg-navy-50">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'} animate-chat-in`}
              >
                <div className={`max-w-[85%] ${msg.sender === 'user' ? '' : ''}`}>
                  <div
                    className={`rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed ${
                      msg.sender === 'user'
                        ? 'bg-primary-600 text-white rounded-br-md'
                        : 'bg-white text-navy-700 shadow-card rounded-bl-md'
                    }`}
                  >
                    {renderText(msg.text)}
                  </div>
                  {msg.sources && msg.sources.length > 0 && (
                    <div className="mt-1.5 space-y-1">
                      <p className="text-xs text-navy-400 font-medium">Source notices:</p>
                      {msg.sources.map((s, i) => (
                        <div key={i} className="flex items-center gap-1.5 text-xs text-primary-600 bg-primary-50 rounded-md px-2 py-1">
                          <Sparkles className="w-3 h-3" />
                          <span className="font-medium">{s.title}</span>
                          <span className="text-navy-400">• {formatDate(s.date)}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}

            {isTyping && (
              <div className="flex justify-start animate-chat-in">
                <div className="bg-white shadow-card rounded-2xl rounded-bl-md px-4 py-3 flex items-center gap-1.5">
                  <span className="w-2 h-2 bg-navy-300 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <span className="w-2 h-2 bg-navy-300 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <span className="w-2 h-2 bg-navy-300 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Suggested questions */}
          {messages.length <= 1 && (
            <div className="px-3 py-2 bg-white border-t border-navy-50">
              <div className="flex flex-wrap gap-1.5">
                {suggestedQuestions.map((q) => (
                  <button
                    key={q}
                    onClick={() => handleSend(q)}
                    className="chip bg-navy-50 text-navy-600 text-xs hover:bg-primary-50 hover:text-primary-700"
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Input */}
          <div className="px-3 py-3 bg-white border-t border-navy-100">
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask about exams, deadlines, events..."
                className="flex-1 px-3.5 py-2.5 bg-navy-50 border border-transparent rounded-lg text-sm placeholder:text-navy-400 focus:outline-none focus:bg-white focus:border-navy-200 focus:ring-2 focus:ring-primary-500/20"
              />
              <button
                onClick={() => handleSend()}
                disabled={!input.trim()}
                className="w-10 h-10 bg-primary-600 text-white rounded-lg flex items-center justify-center hover:bg-primary-700 active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex-shrink-0"
              >
                <Send className="w-4.5 h-4.5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
