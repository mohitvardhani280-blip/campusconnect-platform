import { useApp } from '@/context/AppContext';
import { formatRelativeTime } from '@/data/mockData';
import { priorityConfig, categoryConfig } from '@/lib/uiConfig';
import type { Announcement } from '@/types';
import {
  FileText,
  CalendarDays,
  Briefcase,
  Palmtree,
  BookOpen,
  Info,
  Paperclip,
  AlertTriangle,
  X,
} from 'lucide-react';

const iconMap: Record<string, typeof FileText> = {
  FileText,
  CalendarDays,
  Briefcase,
  Palmtree,
  BookOpen,
  Info,
};

export default function AnnouncementDetail({ announcement, onClose }: { announcement: Announcement; onClose: () => void }) {
  const { } = useApp();
  const cat = categoryConfig[announcement.category];
  const pri = priorityConfig[announcement.priority];
  const Icon = iconMap[cat.icon] || Info;
  const ackRate = announcement.totalRecipients
    ? Math.round((announcement.acknowledged ?? 0) / announcement.totalRecipients * 100)
    : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-navy-950/50 backdrop-blur-sm animate-fade-in p-0 sm:p-4">
      <div className="bg-white w-full sm:max-w-2xl sm:rounded-2xl rounded-t-2xl max-h-[92vh] overflow-y-auto shadow-xl animate-slide-up">
        <div className="sticky top-0 bg-white border-b border-navy-100 px-5 py-3 flex items-center justify-between z-10">
          <div className="flex items-center gap-2 flex-wrap">
            <span className={`badge ${cat.classes}`}>
              <Icon className="w-3 h-3" />
              {announcement.category}
            </span>
            <span className={`badge ${pri.classes}`}>
              {announcement.priority === 'urgent' && <AlertTriangle className="w-3 h-3" />}
              {pri.label}
            </span>
          </div>
          <button onClick={onClose} className="btn-ghost !p-1.5">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="px-5 py-4">
          <h2 className="text-xl font-bold text-navy-900 leading-tight mb-2">{announcement.title}</h2>
          <p className="text-navy-600 text-sm mb-4 leading-relaxed">{announcement.summary}</p>

          <div className="flex flex-wrap gap-3 text-xs text-navy-500 mb-4 pb-4 border-b border-navy-100">
            <span>Published by <strong className="text-navy-700">{announcement.publishedBy}</strong></span>
            <span>•</span>
            <span>{formatRelativeTime(announcement.publishedDate)}</span>
            {announcement.deadline && (
              <>
                <span>•</span>
                <span className="text-warning-700 font-medium">Deadline: {new Date(announcement.deadline).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
              </>
            )}
          </div>

          <p className="text-navy-700 text-sm leading-relaxed whitespace-pre-line mb-5">{announcement.content}</p>

          <div className="flex flex-wrap gap-2 mb-5">
            {announcement.tags?.map((tag) => (
              <span key={tag} className="badge bg-navy-100 text-navy-600">#{tag}</span>
            ))}
          </div>

          {announcement.hasAttachment && (
            <div className="flex items-center gap-3 p-3 bg-navy-50 rounded-lg border border-navy-100 mb-5">
              <div className="w-10 h-10 rounded-lg bg-primary-100 text-primary-700 flex items-center justify-center">
                <Paperclip className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-navy-800">{announcement.attachmentName}</p>
                <p className="text-xs text-navy-500">PDF document</p>
              </div>
              <button className="btn-secondary !py-1.5 !px-3 text-sm">Download</button>
            </div>
          )}

          {announcement.totalRecipients && (
            <div className="p-3 bg-navy-50 rounded-lg border border-navy-100">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-medium text-navy-600">Acknowledgement Status</span>
                <span className="text-xs font-bold text-navy-800">{announcement.acknowledged}/{announcement.totalRecipients} ({ackRate}%)</span>
              </div>
              <div className="h-2 bg-navy-200 rounded-full overflow-hidden">
                <div className="h-full bg-primary-600 rounded-full transition-all" style={{ width: `${ackRate}%` }} />
              </div>
            </div>
          )}

          <div className="flex items-center gap-2 mt-5 text-xs text-navy-400">
            <span>Target: {announcement.targetDepartments.length} dept(s) • Sem {announcement.targetSemesters.join(', ')}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
