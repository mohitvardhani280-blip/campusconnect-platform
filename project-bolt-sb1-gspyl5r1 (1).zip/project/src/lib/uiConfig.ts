import type { Priority, AnnouncementCategory } from '@/types';

export const priorityConfig: Record<Priority, { label: string; classes: string; dot: string }> = {
  urgent: { label: 'Urgent', classes: 'bg-danger-100 text-danger-700', dot: 'bg-danger-500' },
  high: { label: 'High Priority', classes: 'bg-warning-100 text-warning-700', dot: 'bg-warning-500' },
  normal: { label: 'Normal', classes: 'bg-navy-100 text-navy-600', dot: 'bg-navy-400' },
};

export const categoryConfig: Record<AnnouncementCategory, { classes: string; icon: string }> = {
  Academics: { classes: 'bg-primary-100 text-primary-700', icon: 'BookOpen' },
  Examinations: { classes: 'bg-warning-100 text-warning-700', icon: 'FileText' },
  Events: { classes: 'bg-accent-100 text-accent-700', icon: 'CalendarDays' },
  Holidays: { classes: 'bg-success-100 text-success-700', icon: 'Palmtree' },
  Placements: { classes: 'bg-primary-100 text-primary-700', icon: 'Briefcase' },
  General: { classes: 'bg-navy-100 text-navy-600', icon: 'Info' },
};

export function getDaysLabel(days: number): string {
  if (days < 0) return 'Overdue';
  if (days === 0) return 'Today';
  if (days === 1) return 'Tomorrow';
  return `In ${days} days`;
}
