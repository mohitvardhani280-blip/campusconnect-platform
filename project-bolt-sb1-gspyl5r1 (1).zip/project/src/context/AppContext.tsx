import { createContext, useContext, useState, type ReactNode } from 'react';
import type { User, UserRole, ScreenType, Notification, Announcement } from '@/types';
import { currentUser, facultyUser, adminUser, notifications as initialNotifications, announcements as initialAnnouncements } from '@/data/mockData';

interface AppContextType {
  user: User;
  role: UserRole;
  screen: ScreenType;
  isAuthenticated: boolean;
  notifications: Notification[];
  announcements: Announcement[];
  unreadCount: number;
  sidebarOpen: boolean;
  selectedAnnouncementId: string | null;
  setRole: (role: UserRole) => void;
  setScreen: (screen: ScreenType) => void;
  login: () => void;
  logout: () => void;
  toggleSidebar: () => void;
  setSidebarOpen: (open: boolean) => void;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  addAnnouncement: (a: Announcement) => void;
  selectAnnouncement: (id: string | null) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const roleUserMap: Record<UserRole, User> = {
  student: currentUser,
  faculty: facultyUser,
  admin: adminUser,
};

export function AppProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [role, setRoleState] = useState<UserRole>('student');
  const [screen, setScreen] = useState<ScreenType>('login');
  const [notifications, setNotifications] = useState<Notification[]>(initialNotifications);
  const [announcements, setAnnouncements] = useState<Announcement[]>(initialAnnouncements);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [selectedAnnouncementId, setSelectedAnnouncementId] = useState<string | null>(null);

  const user = roleUserMap[role];
  const unreadCount = notifications.filter((n) => !n.read).length;

  const login = () => {
    setIsAuthenticated(true);
    setScreen('dashboard');
  };

  const logout = () => {
    setIsAuthenticated(false);
    setScreen('login');
    setSidebarOpen(false);
  };

  const setRole = (newRole: UserRole) => {
    setRoleState(newRole);
    setScreen('dashboard');
    setSelectedAnnouncementId(null);
  };

  const toggleSidebar = () => setSidebarOpen((prev) => !prev);

  const markNotificationRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const markAllNotificationsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const addAnnouncement = (a: Announcement) => {
    setAnnouncements((prev) => [a, ...prev]);
  };

  const selectAnnouncement = (id: string | null) => {
    setSelectedAnnouncementId(id);
  };

  return (
    <AppContext.Provider
      value={{
        user,
        role,
        screen,
        isAuthenticated,
        notifications,
        announcements,
        unreadCount,
        sidebarOpen,
        selectedAnnouncementId,
        setRole,
        setScreen,
        login,
        logout,
        toggleSidebar,
        setSidebarOpen,
        markNotificationRead,
        markAllNotificationsRead,
        addAnnouncement,
        selectAnnouncement,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

// eslint-disable-next-line react-refresh/only-export-components
export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
