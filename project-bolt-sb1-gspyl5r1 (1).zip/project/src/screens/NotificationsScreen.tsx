import { useApp } from '@/context/AppContext';
import { formatRelativeTime, formatDate } from '@/data/mockData';
import { Bell, BellOff, CheckCheck, FileText, Clock, CalendarDays, AlertTriangle } from 'lucide-react';

const typeConfig = {
  announcement: { icon: FileText, classes: 'bg-primary-100 text-primary-700' },
  deadline: { icon: Clock, classes: 'bg-danger-100 text-danger-700' },
  event: { icon: CalendarDays, classes: 'bg-accent-100 text-accent-700' },
  reminder: { icon: AlertTriangle, classes: 'bg-warning-100 text-warning-700' },
};

export default function NotificationsScreen() {
  const { notifications, markNotificationRead, markAllNotificationsRead, unreadCount } = useApp();

  const sorted = [...notifications].sort((a, b) => b.timestamp.localeCompare(a.timestamp));
  const unread = sorted.filter((n) => !n.read);
  const read = sorted.filter((n) => n.read);

  return (
    <div className="animate-fade-in max-w-3xl">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="text-2xl font-bold text-navy-900 mb-1">Notifications</h1>
          <p className="text-navy-500 text-sm">
            {unreadCount > 0 ? `You have ${unreadCount} unread notification${unreadCount !== 1 ? 's' : ''}.` : 'All caught up! No unread notifications.'}
          </p>
        </div>
        {unreadCount > 0 && (
          <button onClick={markAllNotificationsRead} className="btn-secondary !py-2">
            <CheckCheck className="w-4 h-4" />
            <span className="hidden sm:inline">Mark all read</span>
          </button>
        )}
      </div>

      {sorted.length === 0 ? (
        <div className="card p-12 text-center">
          <div className="w-16 h-16 bg-navy-100 rounded-full flex items-center justify-center mx-auto mb-3">
            <BellOff className="w-8 h-8 text-navy-400" />
          </div>
          <h3 className="font-semibold text-navy-800 mb-1">No notifications yet</h3>
          <p className="text-sm text-navy-500">You'll see new announcements, deadline reminders, and event updates here.</p>
        </div>
      ) : (
        <div className="space-y-5">
          {/* Unread */}
          {unread.length > 0 && (
            <div>
              <h2 className="text-sm font-semibold text-navy-700 mb-2 flex items-center gap-2">
                <Bell className="w-4 h-4 text-primary-600" />
                Unread ({unread.length})
              </h2>
              <div className="space-y-2">
                {unread.map((n) => {
                  const cfg = typeConfig[n.type];
                  const Icon = cfg.icon;
                  return (
                    <button
                      key={n.id}
                      onClick={() => markNotificationRead(n.id)}
                      className="card w-full text-left p-4 flex items-start gap-3 hover:shadow-card-hover transition-all group"
                    >
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${cfg.classes}`}>
                        <Icon className="w-5 h-5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <div className="w-2 h-2 rounded-full bg-primary-500 flex-shrink-0" />
                          <p className="font-semibold text-navy-900 text-sm group-hover:text-primary-700 transition-colors">{n.title}</p>
                        </div>
                        <p className="text-sm text-navy-600 leading-relaxed">{n.message}</p>
                        <p className="text-xs text-navy-400 mt-1.5">{formatRelativeTime(n.timestamp)}</p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Read */}
          {read.length > 0 && (
            <div>
              <h2 className="text-sm font-semibold text-navy-400 mb-2">Read ({read.length})</h2>
              <div className="space-y-2">
                {read.map((n) => {
                  const cfg = typeConfig[n.type];
                  const Icon = cfg.icon;
                  return (
                    <div key={n.id} className="card p-4 flex items-start gap-3 opacity-70">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${cfg.classes}`}>
                        <Icon className="w-5 h-5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-navy-700 text-sm">{n.title}</p>
                        <p className="text-sm text-navy-500 mt-0.5">{n.message}</p>
                        <p className="text-xs text-navy-400 mt-1.5">{formatRelativeTime(n.timestamp)}</p>
                      </div>
                      <CheckCheck className="w-4 h-4 text-navy-300 flex-shrink-0 mt-1" />
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
