import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { allDepartments } from '@/data/mockData';
import type { AnnouncementCategory, Priority, Announcement } from '@/types';
import {
  FilePlus2,
  Send,
  Paperclip,
  X,
  CheckCircle2,
  Calendar,
  Target,
  Tag,
  AlertTriangle,
} from 'lucide-react';

const categories: AnnouncementCategory[] = ['Academics', 'Examinations', 'Events', 'Holidays', 'Placements', 'General'];
const priorities: { value: Priority; label: string; desc: string }[] = [
  { value: 'urgent', label: 'Urgent', desc: 'Time-critical, shows red badge' },
  { value: 'high', label: 'High Priority', desc: 'Important, shows amber badge' },
  { value: 'normal', label: 'Normal', desc: 'Standard announcement' },
];

export default function CreateAnnouncement() {
  const { user, addAnnouncement, setScreen } = useApp();
  const [title, setTitle] = useState('');
  const [summary, setSummary] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState<AnnouncementCategory>('Academics');
  const [priority, setPriority] = useState<Priority>('normal');
  const [deadline, setDeadline] = useState('');
  const [targetDepts, setTargetDepts] = useState<string[]>([]);
  const [targetSems, setTargetSems] = useState<number[]>([]);
  const [tags, setTags] = useState('');
  const [hasAttachment, setHasAttachment] = useState(false);
  const [attachmentName, setAttachmentName] = useState('');
  const [showSuccess, setShowSuccess] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const allSemesters = [1, 2, 3, 4, 5, 6, 7, 8];

  const toggleDept = (dept: string) => {
    setTargetDepts((prev) =>
      prev.includes(dept) ? prev.filter((d) => d !== dept) : [...prev, dept]
    );
  };

  const toggleSem = (sem: number) => {
    setTargetSems((prev) =>
      prev.includes(sem) ? prev.filter((s) => s !== sem) : [...prev, sem]
    );
  };

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!title.trim()) errs.title = 'Title is required';
    if (!summary.trim()) errs.summary = 'Summary is required';
    if (!content.trim()) errs.content = 'Content is required';
    if (targetDepts.length === 0) errs.depts = 'Select at least one department';
    if (targetSems.length === 0) errs.sems = 'Select at least one semester';
    return errs;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }

    const newAnnouncement: Announcement = {
      id: `a${Date.now()}`,
      title: title.trim(),
      summary: summary.trim(),
      content: content.trim(),
      category,
      priority,
      publishedBy: user.name,
      publishedByRole: 'faculty',
      publishedDate: new Date().toISOString(),
      deadline: deadline || undefined,
      targetDepartments: targetDepts,
      targetSemesters: targetSems,
      hasAttachment,
      attachmentName: hasAttachment ? attachmentName || 'document.pdf' : undefined,
      acknowledged: 0,
      totalRecipients: targetDepts.length * targetSems.length * 60,
      tags: tags.split(',').map((t) => t.trim()).filter(Boolean),
    };

    addAnnouncement(newAnnouncement);
    setShowSuccess(true);

    setTimeout(() => {
      setScreen('faculty-my-announcements');
    }, 1800);
  };

  if (showSuccess) {
    return (
      <div className="flex items-center justify-center min-h-[60vh] animate-bounce-in">
        <div className="text-center">
          <div className="w-20 h-20 bg-success-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle2 className="w-10 h-10 text-success-600" />
          </div>
          <h2 className="text-xl font-bold text-navy-900 mb-1">Announcement Published!</h2>
          <p className="text-navy-500 text-sm">Your notice has been sent to {targetDepts.length} department(s) • {targetSems.length} semester(s).</p>
          <p className="text-xs text-navy-400 mt-2">Redirecting to My Announcements...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="animate-fade-in max-w-3xl">
      <div className="mb-5">
        <h1 className="text-2xl font-bold text-navy-900 mb-1 flex items-center gap-2">
          <FilePlus2 className="w-6 h-6 text-primary-600" />
          Create Announcement
        </h1>
        <p className="text-navy-500 text-sm">Publish a notice to specific departments and semesters.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Basic info */}
        <div className="card p-5 space-y-4">
          <h3 className="font-semibold text-navy-900 text-sm uppercase tracking-wide text-navy-400">Basic Information</h3>

          <div>
            <label className="label-text">Title <span className="text-danger-500">*</span></label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter announcement title"
              className="input-field"
            />
            {errors.title && <p className="text-xs text-danger-600 mt-1">{errors.title}</p>}
          </div>

          <div>
            <label className="label-text">Summary <span className="text-danger-500">*</span></label>
            <input
              type="text"
              value={summary}
              onChange={(e) => setSummary(e.target.value)}
              placeholder="One-line summary that appears in cards"
              className="input-field"
            />
            {errors.summary && <p className="text-xs text-danger-600 mt-1">{errors.summary}</p>}
          </div>

          <div>
            <label className="label-text">Full Content <span className="text-danger-500">*</span></label>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Write the full announcement details..."
              rows={5}
              className="input-field resize-none"
            />
            {errors.content && <p className="text-xs text-danger-600 mt-1">{errors.content}</p>}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="label-text">Category</label>
              <select value={category} onChange={(e) => setCategory(e.target.value as AnnouncementCategory)} className="input-field">
                {categories.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>

            <div>
              <label className="label-text">Deadline (optional)</label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-navy-400" />
                <input
                  type="date"
                  value={deadline}
                  onChange={(e) => setDeadline(e.target.value)}
                  className="input-field pl-10"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Priority */}
        <div className="card p-5 space-y-3">
          <h3 className="font-semibold text-navy-400 text-sm uppercase tracking-wide">Priority Level</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {priorities.map((p) => (
              <button
                key={p.value}
                type="button"
                onClick={() => setPriority(p.value)}
                className={`p-3 rounded-lg border-2 text-left transition-all ${
                  priority === p.value
                    ? p.value === 'urgent' ? 'border-danger-500 bg-danger-50' : p.value === 'high' ? 'border-warning-500 bg-warning-50' : 'border-navy-400 bg-navy-50'
                    : 'border-navy-200 bg-white hover:border-navy-300'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  {p.value === 'urgent' && <AlertTriangle className="w-4 h-4 text-danger-500" />}
                  <span className="text-sm font-semibold text-navy-800">{p.label}</span>
                </div>
                <p className="text-xs text-navy-500">{p.desc}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Target audience */}
        <div className="card p-5 space-y-4">
          <h3 className="font-semibold text-navy-400 text-sm uppercase tracking-wide flex items-center gap-2">
            <Target className="w-4 h-4" /> Target Audience
          </h3>

          <div>
            <label className="label-text">Departments <span className="text-danger-500">*</span></label>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => setTargetDepts(targetDepts.length === allDepartments.length ? [] : [...allDepartments])}
                className={`chip ${targetDepts.length === allDepartments.length ? 'bg-primary-600 text-white' : 'bg-navy-50 text-navy-600 hover:bg-navy-100'}`}
              >
                {targetDepts.length === allDepartments.length ? 'Deselect All' : 'Select All'}
              </button>
              {allDepartments.map((dept) => (
                <button
                  key={dept}
                  type="button"
                  onClick={() => toggleDept(dept)}
                  className={`chip ${targetDepts.includes(dept) ? 'bg-primary-600 text-white' : 'bg-navy-50 text-navy-600 hover:bg-navy-100'}`}
                >
                  {dept}
                </button>
              ))}
            </div>
            {errors.depts && <p className="text-xs text-danger-600 mt-1">{errors.depts}</p>}
          </div>

          <div>
            <label className="label-text">Semesters <span className="text-danger-500">*</span></label>
            <div className="flex flex-wrap gap-2">
              {allSemesters.map((sem) => (
                <button
                  key={sem}
                  type="button"
                  onClick={() => toggleSem(sem)}
                  className={`chip ${targetSems.includes(sem) ? 'bg-primary-600 text-white' : 'bg-navy-50 text-navy-600 hover:bg-navy-100'}`}
                >
                  Sem {sem}
                </button>
              ))}
            </div>
            {errors.sems && <p className="text-xs text-danger-600 mt-1">{errors.sems}</p>}
          </div>
        </div>

        {/* Tags & attachment */}
        <div className="card p-5 space-y-4">
          <h3 className="font-semibold text-navy-400 text-sm uppercase tracking-wide">Additional Details</h3>

          <div>
            <label className="label-text">
              <Tag className="w-3.5 h-3.5 inline mr-1" />
              Tags (comma-separated)
            </label>
            <input
              type="text"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              placeholder="e.g. Assignment, CSE-5, Important"
              className="input-field"
            />
          </div>

          <div>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={hasAttachment}
                onChange={(e) => setHasAttachment(e.target.checked)}
                className="rounded border-navy-300 text-primary-600"
              />
              <span className="text-sm font-medium text-navy-700 flex items-center gap-1.5">
                <Paperclip className="w-4 h-4" /> Attach a document
              </span>
            </label>
            {hasAttachment && (
              <input
                type="text"
                value={attachmentName}
                onChange={(e) => setAttachmentName(e.target.value)}
                placeholder="Document name (e.g. Assignment3.pdf)"
                className="input-field mt-2"
              />
            )}
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-3 sticky bottom-0 bg-white py-3 border-t border-navy-100">
          <button type="submit" className="btn-primary flex-1 !py-3">
            <Send className="w-4.5 h-4.5" />
            Publish Announcement
          </button>
          <button type="button" onClick={() => setScreen('dashboard')} className="btn-secondary !py-3">
            <X className="w-4.5 h-4.5" />
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
}
