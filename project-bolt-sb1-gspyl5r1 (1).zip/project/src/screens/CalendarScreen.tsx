import { useState, useMemo } from 'react';
import { useApp } from '@/context/AppContext';
import { events, examSchedule, assignments, formatDate, daysUntil } from '@/data/mockData';
import { ChevronLeft, ChevronRight, CalendarDays, Clock, MapPin } from 'lucide-react';

type CalendarItem = {
  id: string;
  title: string;
  date: string;
  time: string;
  type: 'exam' | 'assignment' | 'event' | 'holiday';
  venue?: string;
  category?: string;
};

export default function CalendarScreen() {
  const { setScreen, selectAnnouncement } = useApp();
  const [currentMonth, setCurrentMonth] = useState(new Date('2026-10-01'));

  const allItems: CalendarItem[] = useMemo(() => {
    const items: CalendarItem[] = [
      ...examSchedule.map((e) => ({ id: e.id, title: `${e.subject} Exam`, date: e.date, time: e.time, type: 'exam' as const, venue: e.room })),
      ...assignments.filter((a) => a.status === 'pending').map((a) => ({ id: a.id, title: a.title, date: a.dueDate, time: '4:00 PM', type: 'assignment' as const })),
      ...events.map((e) => ({ id: e.id, title: e.title, date: e.date, time: e.time, type: e.category === 'Holiday' ? 'holiday' as const : 'event' as const, venue: e.venue, category: e.category })),
    ];
    return items;
  }, []);

  const typeConfig = {
    exam: { label: 'Exam', classes: 'bg-warning-500', border: 'border-warning-500', bg: 'bg-warning-50', text: 'text-warning-700' },
    assignment: { label: 'Assignment', classes: 'bg-danger-500', border: 'border-danger-500', bg: 'bg-danger-50', text: 'text-danger-700' },
    event: { label: 'Event', classes: 'bg-accent-500', border: 'border-accent-500', bg: 'bg-accent-50', text: 'text-accent-700' },
    holiday: { label: 'Holiday', classes: 'bg-success-500', border: 'border-success-500', bg: 'bg-success-50', text: 'text-success-700' },
  };

  const year = currentMonth.getFullYear();
  const month = currentMonth.getMonth();
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const daysInMonth = lastDay.getDate();
  const startDayOfWeek = firstDay.getDay();

  const monthName = currentMonth.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });

  const itemsByDate = useMemo(() => {
    const map: Record<string, CalendarItem[]> = {};
    allItems.forEach((item) => {
      const key = item.date;
      if (!map[key]) map[key] = [];
      map[key].push(item);
    });
    return map;
  }, [allItems]);

  const upcomingItems = allItems
    .filter((i) => daysUntil(i.date) >= 0)
    .sort((a, b) => a.date.localeCompare(b.date))
    .slice(0, 8);

  const goToPrevMonth = () => setCurrentMonth(new Date(year, month - 1, 1));
  const goToNextMonth = () => setCurrentMonth(new Date(year, month + 1, 1));
  const goToToday = () => setCurrentMonth(new Date('2026-10-01'));

  const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const today = '2026-10-09';

  return (
    <div className="animate-fade-in">
      <div className="mb-5">
        <h1 className="text-2xl font-bold text-navy-900 mb-1">Calendar</h1>
        <p className="text-navy-500 text-sm">Exams, assignment deadlines, events, and holidays at a glance.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Calendar grid */}
        <div className="lg:col-span-2 card p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-navy-900">{monthName}</h2>
            <div className="flex items-center gap-1">
              <button onClick={goToPrevMonth} className="btn-ghost !p-2"><ChevronLeft className="w-5 h-5" /></button>
              <button onClick={goToToday} className="btn-secondary !py-1.5 !px-3 text-sm">Today</button>
              <button onClick={goToNextMonth} className="btn-ghost !p-2"><ChevronRight className="w-5 h-5" /></button>
            </div>
          </div>

          <div className="grid grid-cols-7 gap-1 mb-1">
            {weekDays.map((d) => (
              <div key={d} className="text-center text-xs font-semibold text-navy-400 py-2">{d}</div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-1">
            {Array.from({ length: startDayOfWeek }).map((_, i) => (
              <div key={`empty-${i}`} className="aspect-square" />
            ))}
            {Array.from({ length: daysInMonth }).map((_, i) => {
              const day = i + 1;
              const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
              const dayItems = itemsByDate[dateStr] || [];
              const isToday = dateStr === today;

              return (
                <div
                  key={day}
                  className={`aspect-square rounded-lg p-1.5 border transition-all ${
                    isToday
                      ? 'border-primary-500 bg-primary-50'
                      : dayItems.length > 0
                      ? 'border-navy-100 bg-navy-50/50 hover:border-navy-200'
                      : 'border-navy-50'
                  }`}
                >
                  <div className={`text-xs font-medium ${isToday ? 'text-primary-700' : 'text-navy-600'}`}>{day}</div>
                  <div className="mt-1 space-y-0.5">
                    {dayItems.slice(0, 3).map((item) => {
                      const cfg = typeConfig[item.type];
                      return (
                        <div key={item.id} className={`text-[10px] leading-tight px-1 py-0.5 rounded ${cfg.bg} ${cfg.text} font-medium truncate`}>
                          {item.title}
                        </div>
                      );
                    })}
                    {dayItems.length > 3 && (
                      <div className="text-[10px] text-navy-400 font-medium">+{dayItems.length - 3} more</div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Legend */}
          <div className="flex flex-wrap items-center gap-3 mt-4 pt-3 border-t border-navy-100">
            {Object.entries(typeConfig).map(([key, cfg]) => (
              <div key={key} className="flex items-center gap-1.5">
                <span className={`w-3 h-3 rounded ${cfg.classes}`} />
                <span className="text-xs text-navy-600">{cfg.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Upcoming list */}
        <div className="card p-4">
          <h3 className="font-bold text-navy-900 mb-3 flex items-center gap-2">
            <CalendarDays className="w-5 h-5 text-primary-600" />
            What's Coming Up
          </h3>
          <div className="space-y-2 max-h-[600px] overflow-y-auto">
            {upcomingItems.map((item) => {
              const cfg = typeConfig[item.type];
              const d = daysUntil(item.date);
              return (
                <div key={`${item.id}`} className={`p-3 rounded-lg border-l-4 ${cfg.border} ${cfg.bg}`}>
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <span className={`text-xs font-semibold ${cfg.text}`}>{cfg.label}</span>
                    <span className={`text-xs font-medium ${d <= 3 ? 'text-danger-600' : 'text-navy-500'}`}>
                      {d === 0 ? 'Today' : d === 1 ? 'Tomorrow' : `${d} days away`}
                    </span>
                  </div>
                  <p className="text-sm font-medium text-navy-800 leading-tight">{item.title}</p>
                  <div className="flex items-center gap-3 mt-1.5 text-xs text-navy-500">
                    <span className="flex items-center gap-1">
                      <CalendarDays className="w-3 h-3" /> {formatDate(item.date)}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" /> {item.time}
                    </span>
                  </div>
                  {item.venue && (
                    <span className="flex items-center gap-1 text-xs text-navy-500 mt-1">
                      <MapPin className="w-3 h-3" /> {item.venue}
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
