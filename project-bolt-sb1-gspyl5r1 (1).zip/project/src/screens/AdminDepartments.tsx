import { departments } from '@/data/mockData';
import { Building2, Users, BookOpen, GraduationCap, ChevronRight } from 'lucide-react';

export default function AdminDepartments() {
  const totalStudents = departments.reduce((sum, d) => sum + d.students, 0);
  const totalFaculty = departments.reduce((sum, d) => sum + d.faculty, 0);

  return (
    <div className="animate-fade-in">
      <div className="mb-5">
        <h1 className="text-2xl font-bold text-navy-900 mb-1">Departments</h1>
        <p className="text-navy-500 text-sm">{departments.length} departments • {totalStudents} students • {totalFaculty} faculty</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {departments.map((dept) => (
          <div key={dept.id} className="card p-5 hover:shadow-card-hover transition-all cursor-pointer group">
            <div className="flex items-start justify-between mb-3">
              <div className="w-12 h-12 rounded-xl bg-primary-100 text-primary-700 flex items-center justify-center">
                <Building2 className="w-6 h-6" />
              </div>
              <span className="text-xs font-bold text-navy-400 bg-navy-50 px-2 py-1 rounded-md">{dept.code}</span>
            </div>

            <h3 className="font-bold text-navy-900 text-sm mb-1 group-hover:text-primary-700 transition-colors">{dept.name}</h3>
            <p className="text-xs text-navy-500 mb-3">HoD: {dept.hod}</p>

            <div className="grid grid-cols-3 gap-2 pt-3 border-t border-navy-100">
              <div className="text-center">
                <div className="flex items-center justify-center mb-1">
                  <GraduationCap className="w-4 h-4 text-primary-600" />
                </div>
                <div className="text-lg font-bold text-navy-900">{dept.students}</div>
                <div className="text-[10px] text-navy-400">Students</div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center mb-1">
                  <BookOpen className="w-4 h-4 text-accent-600" />
                </div>
                <div className="text-lg font-bold text-navy-900">{dept.faculty}</div>
                <div className="text-[10px] text-navy-400">Faculty</div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center mb-1">
                  <Users className="w-4 h-4 text-navy-600" />
                </div>
                <div className="text-lg font-bold text-navy-900">{dept.semesters}</div>
                <div className="text-[10px] text-navy-400">Semesters</div>
              </div>
            </div>

            <button className="w-full mt-3 flex items-center justify-between text-sm text-primary-600 font-medium group-hover:text-primary-700">
              <span>Manage Department</span>
              <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
