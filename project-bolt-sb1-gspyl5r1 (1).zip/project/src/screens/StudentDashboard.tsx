import { useApp } from '@/context/AppContext';
import { announcements, examSchedule, assignments, events, formatDate, daysUntil } from '@/data/mockData';
import { getDaysLabel } from '@/lib/uiConfig';
import AnnouncementCard from '@/components/AnnouncementCard';
import { priorityConfig, categoryConfig } from '@/lib/uiConfig';
import {
  TrendingUp,
  CalendarClock,
  BookOpen,
  Award,
  Clock,
  AlertTriangle,
  CheckCircle2,
  FileText,
  CalendarDays,
  ArrowRight,
  Sparkles,
  GraduationCap,
} from 'lucide-react';
import type { ScreenType } from '@/types';

export default function StudentDashboard() {
  const { user, announcements: allAnnouncements, setScreen } = useApp();

  const urgentNotices = allAnnouncements.filter((a) => a.priority === 'urgent').slice(0, 3);
  const recentNotices = allAnnouncements.filter((a) => a.priority !== 'urgent').slice(0, 4);
  const upcomingExams = examSchedule.filter((e) => daysUntil(e.date) >= 0).slice(0, 4);
  const pendingAssignments = assignments.filter((a) => a.status === 'pending').slice(0, 3);
  const upcomingEvents = events.filter((e) => daysUntil(e.date) >= 0).slice(0, 3);

  const stats = [
    { label: 'Active Notices', value: allAnnouncements.length, icon: FileText, color: 'primary' },
    { label: 'Upcoming Exams', value: upcomingExams.length, icon: CalendarClock, color: 'warning' },
    { label: 'Pending Tasks', value: pendingAssignments.length, icon: BookOpen, color: 'danger' },
    { label: 'Events This Month', value: upcomingEvents.length, icon: CalendarDays, color: 'accent' },
  ];

  const statColorMap: Record<string, string> = {
    primary: 'bg-primary-100 text-primary-700',
    warning: 'bg-warning-100 text-warning-700',
    danger: 'bg-danger-100 text-danger-700',
    accent: 'bg-accent-100 text-accent-700',
  };

  const goToScreen = (s: ScreenType) => setScreen(s);

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Welcome banner */}
      <div className="relative overflow-hidden bg-gradient-to-r from-navy-900 to-navy-800 rounded-xl p-6 text-white">
        <div className="absolute top-0 right-0 w-64 h-64 bg-primary-600/20 rounded-full blur-3xl -mr-20 -mt-20" />
        <div className="absolute bottom-0 left-1/3 w-48 h-48 bg-accent-600/10 rounded-full blur-3xl" />
        <div className="relative z-10 flex items-center justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Sparkles className="w-4 h-4 text-primary-400" />
              <span className="text-sm text-navy-300">{new Date('2026-10-09').toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</span>
            </div>
            <h1 className="text-2xl font-bold mb-1">Welcome back, {user.name.split(' ')[0]}!</h1>
            <p className="text-navy-300 text-sm">
              {user.department} • Semester {user.semester} • You have {urgentNotices.length} urgent notice{urgentNotices.length !== 1 ? 's' : ''} and {upcomingExams.length} upcoming exam{upcomingExams.length !== 1 ? 's' : ''}.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-center px-4 py-2 bg-white/10 rounded-lg backdrop-blur-sm">
              <div className="text-2xl font-bold">{daysUntil('2026-10-20')}</div>
              <div className="text-xs text-navy-300">days to first exam</div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.label} className="card p-4">
              <div className="flex items-center justify-between mb-2">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${statColorMap[s.color]}`}>
                  <Icon className="w-5 h-5" />
                </div>
              </div>
              <div className="text-2xl font-bold text-navy-900">{s.value}</div>
              <div className="text-xs text-navy-500">{s.label}</div>
            </div>
          );
        })}
      </div>

      {/* AI suggestion banner */}
      <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-primary-50 to-accent-50 rounded-xl border border-primary-100">
        <div className="w-10 h-10 bg-primary-600 rounded-lg flex items-center justify-center flex-shrink-0">
          <Sparkles className="w-5 h-5 text-white" />
        </div>
        <div className="flex-1">
          <p className="text-sm font-semibold text-navy-800">AI Recommendation</p>
          <p className="text-xs text-navy-600">Based on your department and semester, prioritize the DBMS assignment (due in {daysUntil('2026-10-18')} days) and start exam prep for Database Management Systems.</p>
        </div>
        <button onClick={() => goToScreen('noticeboard')} className="btn-secondary !py-1.5 !px-3 text-sm hidden sm:flex">
          View All
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Main column */}
        <div className="lg:col-span-2 space-y-5">
          {/* Urgent notices */}
          {urgentNotices.length > 0 && (
            <div>
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-lg font-bold text-navy-900 flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-danger-500" />
                  Urgent Notices
                </h2>
                <button onClick={() => goToScreen('noticeboard')} className="text-sm text-primary-600 font-medium hover:text-primary-700 flex items-center gap-1">
                  View all <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="space-y-3">
                {urgentNotices.map((a) => (
                  <AnnouncementCard key={a.id} announcement={a} />
                ))}
              </div>
            </div>
          )}

          {/* Recent notices */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-lg font-bold text-navy-900">Recent Announcements</h2>
              <button onClick={() => goToScreen('noticeboard')} className="text-sm text-primary-600 font-medium hover:text-primary-700 flex items-center gap-1">
                View all <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="grid sm:grid-cols-2 gap-3">
              {recentNotices.map((a) => (
                <AnnouncementCard key={a.id} announcement={a} compact />
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar column */}
        <div className="space-y-5">
          {/* Upcoming exams */}
          <div className="card p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-navy-900 flex items-center gap-2">
                <CalendarClock className="w-5 h-5 text-warning-600" />
                Upcoming Exams
              </h3>
              <button onClick={() => goToScreen('calendar')} className="text-xs text-primary-600 font-medium">Calendar</button>
            </div>
            <div className="space-y-2">
              {upcomingExams.map((e) => {
                const d = daysUntil(e.date);
                return (
                  <div key={e.id} className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-navy-50 transition-colors">
                    <div className={`w-12 h-12 rounded-lg flex flex-col items-center justify-center flex-shrink-0 ${d <= 7 ? 'bg-danger-100 text-danger-700' : 'bg-warning-100 text-warning-700'}`}>
                      <span className="text-lg font-bold leading-none">{d}</span>
                      <span className="text-[10px] leading-none mt-0.5">days</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-navy-800 truncate">{e.subject}</p>
                      <p className="text-xs text-navy-500">{e.time} • {e.room}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Pending assignments */}
          <div className="card p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-navy-900 flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-primary-600" />
                Pending Assignments
              </h3>
            </div>
            <div className="space-y-2">
              {pendingAssignments.map((a) => {
                const d = daysUntil(a.dueDate);
                return (
                  <div key={a.id} className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-navy-50 transition-colors">
                    <div className={`w-2 h-2 rounded-full flex-shrink-0 ${d <= 3 ? 'bg-danger-500' : 'bg-warning-500'}`} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-navy-800 truncate">{a.title}</p>
                      <p className="text-xs text-navy-500">{a.subject}</p>
                    </div>
                    <span className={`text-xs font-medium flex-shrink-0 ${d <= 3 ? 'text-danger-600' : 'text-warning-600'}`}>
                      {getDaysLabel(d)}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Upcoming events */}
          <div className="card p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-navy-900 flex items-center gap-2">
                <CalendarDays className="w-5 h-5 text-accent-600" />
                Upcoming Events
              </h3>
            </div>
            <div className="space-y-2">
              {upcomingEvents.map((e) => (
                <div key={e.id} className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-navy-50 transition-colors">
                  <div className="w-10 h-10 rounded-lg bg-accent-100 text-accent-700 flex flex-col items-center justify-center flex-shrink-0">
                    <span className="text-sm font-bold leading-none">{new Date(e.date).getDate()}</span>
                    <span className="text-[9px] leading-none mt-0.5">{new Date(e.date).toLocaleDateString('en-IN', { month: 'short' })}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-navy-800 truncate">{e.title}</p>
                    <p className="text-xs text-navy-500">{e.time} • {e.venue}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
