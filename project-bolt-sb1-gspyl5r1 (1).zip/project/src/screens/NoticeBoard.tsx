import { useState, useMemo } from 'react';
import { useApp } from '@/context/AppContext';
import AnnouncementCard from '@/components/AnnouncementCard';
import AnnouncementDetail from '@/components/AnnouncementDetail';
import type { AnnouncementCategory, Priority } from '@/types';
import { Search, SlidersHorizontal, X, FileText, CalendarDays, Briefcase, Palmtree, BookOpen, Info, AlertTriangle } from 'lucide-react';

const categories: (AnnouncementCategory | 'All')[] = ['All', 'Academics', 'Examinations', 'Events', 'Holidays', 'Placements', 'General'];
const priorities: (Priority | 'all')[] = ['all', 'urgent', 'high', 'normal'];

const catIconMap: Record<string, typeof FileText> = {
  Academics: BookOpen,
  Examinations: FileText,
  Events: CalendarDays,
  Holidays: Palmtree,
  Placements: Briefcase,
  General: Info,
};

export default function NoticeBoard() {
  const { announcements, selectedAnnouncementId, selectAnnouncement } = useApp();
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState<AnnouncementCategory | 'All'>('All');
  const [activePriority, setActivePriority] = useState<Priority | 'all'>('all');
  const [showFilters, setShowFilters] = useState(false);

  const filtered = useMemo(() => {
    return announcements.filter((a) => {
      if (activeCategory !== 'All' && a.category !== activeCategory) return false;
      if (activePriority !== 'all' && a.priority !== activePriority) return false;
      if (search) {
        const q = search.toLowerCase();
        if (!a.title.toLowerCase().includes(q) && !a.summary.toLowerCase().includes(q) && !a.content.toLowerCase().includes(q)) return false;
      }
      return true;
    });
  }, [announcements, activeCategory, activePriority, search]);

  const selectedAnnouncement = announcements.find((a) => a.id === selectedAnnouncementId);

  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    announcements.forEach((a) => {
      counts[a.category] = (counts[a.category] || 0) + 1;
    });
    return counts;
  }, [announcements]);

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="mb-5">
        <h1 className="text-2xl font-bold text-navy-900 mb-1">Central Notice Board</h1>
        <p className="text-navy-500 text-sm">All official college announcements in one place. {announcements.length} notices published.</p>
      </div>

      {/* Category tabs */}
      <div className="flex items-center gap-2 mb-4 overflow-x-auto pb-1">
        {categories.map((cat) => {
          const count = cat === 'All' ? announcements.length : categoryCounts[cat] || 0;
          const Icon = cat === 'All' ? Info : catIconMap[cat];
          return (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`chip flex-shrink-0 ${
                activeCategory === cat
                  ? 'bg-primary-600 text-white'
                  : 'bg-white text-navy-600 border border-navy-200 hover:border-navy-300'
              }`}
            >
              {Icon && <Icon className="w-3.5 h-3.5" />}
              {cat}
              <span className={`text-xs ${activeCategory === cat ? 'text-primary-200' : 'text-navy-400'}`}>({count})</span>
            </button>
          );
        })}
      </div>

      {/* Search & filters bar */}
      <div className="flex items-center gap-3 mb-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-navy-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search announcements..."
            className="input-field pl-10"
          />
          {search && (
            <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-navy-400 hover:text-navy-600">
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
        <button
          onClick={() => setShowFilters(!showFilters)}
          className={`btn-secondary !px-3 ${showFilters ? 'border-primary-500 text-primary-700' : ''}`}
        >
          <SlidersHorizontal className="w-4 h-4" />
          <span className="hidden sm:inline">Filters</span>
        </button>
      </div>

      {/* Filter panel */}
      {showFilters && (
        <div className="card p-4 mb-4 animate-slide-up">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-navy-800">Filter by Priority</h3>
            {(activePriority !== 'all' || search || activeCategory !== 'All') && (
              <button
                onClick={() => { setActivePriority('all'); setActiveCategory('All'); setSearch(''); }}
                className="text-xs text-primary-600 font-medium"
              >
                Clear all
              </button>
            )}
          </div>
          <div className="flex flex-wrap gap-2">
            {priorities.map((p) => (
              <button
                key={p}
                onClick={() => setActivePriority(p)}
                className={`chip ${
                  activePriority === p
                    ? p === 'urgent' ? 'bg-danger-500 text-white' : p === 'high' ? 'bg-warning-500 text-white' : p === 'normal' ? 'bg-navy-600 text-white' : 'bg-primary-600 text-white'
                    : 'bg-navy-50 text-navy-600 hover:bg-navy-100'
                }`}
              >
                {p === 'all' ? 'All Priorities' : p === 'urgent' ? 'Urgent' : p === 'high' ? 'High Priority' : 'Normal'}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Results count */}
      <div className="mb-3 text-sm text-navy-500">
        Showing {filtered.length} notice{filtered.length !== 1 ? 's' : ''}
      </div>

      {/* Announcement grid */}
      {filtered.length === 0 ? (
        <div className="card p-12 text-center">
          <div className="w-16 h-16 bg-navy-100 rounded-full flex items-center justify-center mx-auto mb-3">
            <FileText className="w-8 h-8 text-navy-400" />
          </div>
          <h3 className="font-semibold text-navy-800 mb-1">No notices found</h3>
          <p className="text-sm text-navy-500">Try adjusting your search or filters to see more results.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filtered.map((a) => (
            <AnnouncementCard key={a.id} announcement={a} />
          ))}
        </div>
      )}

      {/* Detail modal */}
      {selectedAnnouncement && (
        <AnnouncementDetail announcement={selectedAnnouncement} onClose={() => selectAnnouncement(null)} />
      )}
    </div>
  );
}
