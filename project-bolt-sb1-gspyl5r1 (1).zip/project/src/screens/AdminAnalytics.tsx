import { announcements, departments, managedUsers, notifications } from '@/data/mockData';
import { formatDate } from '@/data/mockData';
import { priorityConfig, categoryConfig } from '@/lib/uiConfig';
import {
  BarChart3,
  TrendingUp,
  Users,
  Megaphone,
  Eye,
  CheckCircle2,
  FileText,
  Building2,
  Activity,
  GraduationCap,
} from 'lucide-react';
import type { AnnouncementCategory } from '@/types';

export default function AdminAnalytics() {
  const totalReach = announcements.reduce((sum, a) => sum + (a.totalRecipients || 0), 0);
  const totalAcks = announcements.reduce((sum, a) => sum + (a.acknowledged || 0), 0);
  const ackRate = totalReach > 0 ? Math.round((totalAcks / totalReach) * 100) : 0;

  const categoryStats = announcements.reduce((acc, a) => {
    acc[a.category] = (acc[a.category] || 0) + 1;
    return acc;
  }, {} as Record<AnnouncementCategory, number>);

  const sortedCategories = Object.entries(categoryStats).sort((a, b) => b[1] - a[1]);

  const topAnnouncements = [...announcements]
    .sort((a, b) => (b.acknowledged || 0) - (a.acknowledged || 0))
    .slice(0, 5);

  const stats = [
    { label: 'Total Announcements', value: announcements.length, icon: Megaphone, color: 'bg-primary-100 text-primary-700', trend: '+12%' },
    { label: 'Total Reach', value: totalReach.toLocaleString(), icon: Eye, color: 'bg-accent-100 text-accent-700', trend: '+8%' },
    { label: 'Acknowledgement Rate', value: ackRate + '%', icon: CheckCircle2, color: 'bg-success-100 text-success-700', trend: '+5%' },
    { label: 'Active Users', value: managedUsers.filter((u) => u.status === 'active').length, icon: Users, color: 'bg-warning-100 text-warning-700', trend: '+3%' },
  ];

  // Simple bar chart data for monthly activity
  const monthlyData = [
    { month: 'Jun', value: 45 },
    { month: 'Jul', value: 62 },
    { month: 'Aug', value: 78 },
    { month: 'Sep', value: 95 },
    { month: 'Oct', value: 110 },
  ];
  const maxMonthly = Math.max(...monthlyData.map((d) => d.value));

  return (
    <div className="animate-fade-in space-y-5">
      <div className="mb-1">
        <h1 className="text-2xl font-bold text-navy-900 mb-1">Platform Analytics</h1>
        <p className="text-navy-500 text-sm">Monitor communication activity and announcement reach across the college.</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.label} className="card p-4">
              <div className="flex items-center justify-between mb-2">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${s.color}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <span className="text-xs font-semibold text-success-600 flex items-center gap-0.5">
                  <TrendingUp className="w-3 h-3" />
                  {s.trend}
                </span>
              </div>
              <div className="text-2xl font-bold text-navy-900">{s.value}</div>
              <div className="text-xs text-navy-500">{s.label}</div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Activity chart */}
        <div className="card p-5">
          <h3 className="font-bold text-navy-900 mb-1 flex items-center gap-2">
            <Activity className="w-5 h-5 text-primary-600" />
            Monthly Announcement Activity
          </h3>
          <p className="text-xs text-navy-500 mb-4">Number of notices published per month</p>
          <div className="flex items-end justify-between gap-3 h-48">
            {monthlyData.map((d) => (
              <div key={d.month} className="flex-1 flex flex-col items-center gap-2">
                <div className="w-full flex flex-col justify-end h-full">
                  <div
                    className="w-full bg-gradient-to-t from-primary-600 to-primary-400 rounded-t-lg transition-all hover:from-primary-700 hover:to-primary-500 relative group"
                    style={{ height: `${(d.value / maxMonthly) * 100}%` }}
                  >
                    <span className="absolute -top-6 left-1/2 -translate-x-1/2 text-xs font-bold text-navy-700 opacity-0 group-hover:opacity-100 transition-opacity">
                      {d.value}
                    </span>
                  </div>
                </div>
                <span className="text-xs text-navy-500 font-medium">{d.month}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Category breakdown */}
        <div className="card p-5">
          <h3 className="font-bold text-navy-900 mb-1 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-accent-600" />
            Announcements by Category
          </h3>
          <p className="text-xs text-navy-500 mb-4">Distribution across notice types</p>
          <div className="space-y-3">
            {sortedCategories.map(([cat, count]) => {
              const pct = Math.round((count / announcements.length) * 100);
              const cfg = categoryConfig[cat as AnnouncementCategory];
              return (
                <div key={cat}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-navy-700">{cat}</span>
                    <span className="text-xs text-navy-500">{count} ({pct}%)</span>
                  </div>
                  <div className="h-2.5 bg-navy-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${cfg.classes.split(' ')[0].replace('text', 'bg')}`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Top announcements & department reach */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Top announcements */}
        <div className="card p-5">
          <h3 className="font-bold text-navy-900 mb-3 flex items-center gap-2">
            <Megaphone className="w-5 h-5 text-primary-600" />
            Top Announcements by Reach
          </h3>
          <div className="space-y-2">
            {topAnnouncements.map((a, i) => {
              const pri = priorityConfig[a.priority];
              return (
                <div key={a.id} className="flex items-center gap-3 p-3 rounded-lg hover:bg-navy-50 transition-colors">
                  <span className="w-6 h-6 rounded-full bg-navy-100 text-navy-600 text-xs font-bold flex items-center justify-center flex-shrink-0">
                    {i + 1}
                  </span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-navy-800 truncate">{a.title}</p>
                    <p className="text-xs text-navy-500">{a.publishedBy} • {formatDate(a.publishedDate)}</p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <div className="text-sm font-bold text-navy-900">{a.acknowledged}</div>
                    <div className="text-xs text-navy-400">reads</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Department reach */}
        <div className="card p-5">
          <h3 className="font-bold text-navy-900 mb-3 flex items-center gap-2">
            <Building2 className="w-5 h-5 text-accent-600" />
            Department Overview
          </h3>
          <div className="space-y-2">
            {departments.map((d) => (
              <div key={d.id} className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-navy-50 transition-colors">
                <div className="w-8 h-8 rounded-lg bg-navy-100 text-navy-600 text-xs font-bold flex items-center justify-center flex-shrink-0">
                  {d.code}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-navy-700 truncate">{d.name}</p>
                </div>
                <div className="flex items-center gap-3 text-xs flex-shrink-0">
                  <span className="flex items-center gap-1 text-navy-500">
                    <GraduationCap className="w-3.5 h-3.5" /> {d.students}
                  </span>
                  <span className="flex items-center gap-1 text-navy-500">
                    <FileText className="w-3.5 h-3.5" /> {d.faculty}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
