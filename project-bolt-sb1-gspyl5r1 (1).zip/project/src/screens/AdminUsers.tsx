import { useState, useMemo } from 'react';
import { useApp } from '@/context/AppContext';
import { managedUsers, departments, announcements, formatDate } from '@/data/mockData';
import {
  Users,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Clock,
  Shield,
  GraduationCap,
  BookOpen,
  MoreVertical,
  UserPlus,
} from 'lucide-react';
import type { UserRole } from '@/types';

export default function AdminUsers() {
  const { } = useApp();
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState<UserRole | 'all'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive' | 'pending'>('all');

  const filtered = useMemo(() => {
    return managedUsers.filter((u) => {
      if (roleFilter !== 'all' && u.role !== roleFilter) return false;
      if (statusFilter !== 'all' && u.status !== statusFilter) return false;
      if (search) {
        const q = search.toLowerCase();
        if (!u.name.toLowerCase().includes(q) && !u.email.toLowerCase().includes(q) && !u.department.toLowerCase().includes(q)) return false;
      }
      return true;
    });
  }, [search, roleFilter, statusFilter]);

  const statusConfig = {
    active: { label: 'Active', classes: 'bg-success-100 text-success-700', icon: CheckCircle2 },
    inactive: { label: 'Inactive', classes: 'bg-navy-100 text-navy-600', icon: XCircle },
    pending: { label: 'Pending', classes: 'bg-warning-100 text-warning-700', icon: Clock },
  };

  const roleConfig = {
    student: { icon: GraduationCap, classes: 'text-primary-600 bg-primary-100' },
    faculty: { icon: BookOpen, classes: 'text-accent-600 bg-accent-100' },
    admin: { icon: Shield, classes: 'text-navy-700 bg-navy-200' },
  };

  const stats = [
    { label: 'Total Users', value: managedUsers.length, icon: Users },
    { label: 'Students', value: managedUsers.filter((u) => u.role === 'student').length, icon: GraduationCap },
    { label: 'Faculty', value: managedUsers.filter((u) => u.role === 'faculty').length, icon: BookOpen },
    { label: 'Pending', value: managedUsers.filter((u) => u.status === 'pending').length, icon: Clock },
  ];

  return (
    <div className="animate-fade-in">
      <div className="flex items-center justify-between mb-5 flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-navy-900 mb-1">User Management</h1>
          <p className="text-navy-500 text-sm">Manage students, faculty, and admin accounts.</p>
        </div>
        <button className="btn-primary">
          <UserPlus className="w-4 h-4" />
          Add User
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.label} className="card p-4">
              <Icon className="w-5 h-5 text-primary-600 mb-2" />
              <div className="text-2xl font-bold text-navy-900">{s.value}</div>
              <div className="text-xs text-navy-500">{s.label}</div>
            </div>
          );
        })}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3 mb-4 flex-wrap">
        <div className="flex-1 min-w-[200px] relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-navy-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name, email, or department..."
            className="input-field pl-10"
          />
        </div>
        <select value={roleFilter} onChange={(e) => setRoleFilter(e.target.value as UserRole | 'all')} className="input-field !w-auto">
          <option value="all">All Roles</option>
          <option value="student">Students</option>
          <option value="faculty">Faculty</option>
          <option value="admin">Admins</option>
        </select>
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as 'all' | 'active' | 'inactive' | 'pending')} className="input-field !w-auto">
          <option value="all">All Status</option>
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
          <option value="pending">Pending</option>
        </select>
      </div>

      {/* User table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-navy-100 bg-navy-50">
                <th className="text-left px-4 py-3 text-xs font-semibold text-navy-500 uppercase tracking-wide">Name</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-navy-500 uppercase tracking-wide hidden sm:table-cell">Role</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-navy-500 uppercase tracking-wide hidden md:table-cell">Department</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-navy-500 uppercase tracking-wide hidden lg:table-cell">Joined</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-navy-500 uppercase tracking-wide">Status</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((u) => {
                const sCfg = statusConfig[u.status];
                const rCfg = roleConfig[u.role];
                const SIcon = sCfg.icon;
                const RIcon = rCfg.icon;
                return (
                  <tr key={u.id} className="border-b border-navy-50 hover:bg-navy-50/50 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-primary-600 text-white text-xs font-bold flex items-center justify-center flex-shrink-0">
                          {u.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-navy-900 truncate">{u.name}</p>
                          <p className="text-xs text-navy-500 truncate">{u.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 hidden sm:table-cell">
                      <span className={`badge ${rCfg.classes}`}>
                        <RIcon className="w-3 h-3" />
                        <span className="capitalize">{u.role}</span>
                      </span>
                      {u.semester && <span className="text-xs text-navy-400 ml-1">Sem {u.semester}</span>}
                    </td>
                    <td className="px-4 py-3 hidden md:table-cell text-sm text-navy-600">{u.department}</td>
                    <td className="px-4 py-3 hidden lg:table-cell text-sm text-navy-500">{formatDate(u.joinedDate)}</td>
                    <td className="px-4 py-3">
                      <span className={`badge ${sCfg.classes}`}>
                        <SIcon className="w-3 h-3" />
                        {sCfg.label}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <button className="btn-ghost !p-1.5">
                        <MoreVertical className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <div className="p-12 text-center">
            <p className="text-sm text-navy-400">No users match your filters.</p>
          </div>
        )}
      </div>
    </div>
  );
}
