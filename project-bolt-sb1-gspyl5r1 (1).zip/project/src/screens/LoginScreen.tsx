import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import type { UserRole } from '@/types';
import { GraduationCap, Mail, Lock, Eye, EyeOff, ArrowRight, Shield, Users, BookOpen, Sparkles } from 'lucide-react';

export default function LoginScreen() {
  const { login, setRole } = useApp();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [selectedRole, setSelectedRole] = useState<UserRole>('student');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [name, setName] = useState('');
  const [department, setDepartment] = useState('');

  const roleCards: { role: UserRole; label: string; desc: string; icon: typeof Users }[] = [
    { role: 'student', label: 'Student', desc: 'View notices, exams & events', icon: BookOpen },
    { role: 'faculty', label: 'Faculty', desc: 'Publish & manage announcements', icon: Users },
    { role: 'admin', label: 'Admin', desc: 'Manage users & platform', icon: Shield },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRole(selectedRole);
    login();
  };

  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      {/* Left brand panel */}
      <div className="lg:w-2/5 bg-navy-950 text-white p-8 lg:p-12 flex flex-col justify-between relative overflow-hidden">
        <div className="absolute top-0 right-0 w-72 h-72 bg-primary-600/20 rounded-full blur-3xl -mr-20 -mt-20" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-accent-600/10 rounded-full blur-3xl -ml-16 -mb-16" />

        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-12">
            <div className="w-11 h-11 bg-primary-600 rounded-xl flex items-center justify-center">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold">CampusConnect AI</h1>
              <p className="text-xs text-navy-300">National Institute of Technology</p>
            </div>
          </div>

          <div className="max-w-sm">
            <h2 className="text-2xl lg:text-3xl font-bold leading-tight mb-4">
              All your college communication, in one place.
            </h2>
            <p className="text-navy-300 text-sm leading-relaxed mb-8">
              Stop chasing announcements across WhatsApp groups, emails, and notice boards.
              Everything official, organized, and AI-powered — for students, faculty, and administration.
            </p>

            <div className="space-y-3">
              {[
                { icon: Sparkles, text: 'AI chatbot answers from verified college data' },
                { icon: BookOpen, text: 'Centralized notice board with smart categories' },
                { icon: Shield, text: 'Role-based access for students, faculty & admin' },
              ].map((f, i) => (
                <div key={i} className="flex items-center gap-3 text-sm text-navy-200">
                  <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center flex-shrink-0">
                    <f.icon className="w-4 h-4 text-primary-400" />
                  </div>
                  <span>{f.text}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="relative z-10 text-xs text-navy-400 mt-8">
          © 2026 CampusConnect AI — NIFT. For demonstration purposes.
        </div>
      </div>

      {/* Right form panel */}
      <div className="lg:w-3/5 flex-1 flex items-center justify-center p-6 lg:p-12 bg-navy-50">
        <div className="w-full max-w-md">
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2 lg:hidden">
              <div className="w-9 h-9 bg-primary-600 rounded-lg flex items-center justify-center">
                <GraduationCap className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-lg font-bold text-navy-900">CampusConnect AI</h1>
            </div>
            <h2 className="text-2xl font-bold text-navy-900">
              {mode === 'login' ? 'Welcome back' : 'Create your account'}
            </h2>
            <p className="text-navy-500 text-sm mt-1">
              {mode === 'login' ? 'Sign in to access your college dashboard' : 'Register with your college email to get started'}
            </p>
          </div>

          {/* Role selector */}
          <div className="mb-5">
            <label className="label-text">I am a</label>
            <div className="grid grid-cols-3 gap-2">
              {roleCards.map((r) => {
                const Icon = r.icon;
    return (
                  <button
                    key={r.role}
                    onClick={() => setSelectedRole(r.role)}
                    className={`p-3 rounded-lg border-2 text-center transition-all ${
                      selectedRole === r.role
                        ? 'border-primary-600 bg-primary-50 text-primary-700'
                        : 'border-navy-200 bg-white text-navy-600 hover:border-navy-300'
                    }`}
                  >
                    <Icon className="w-5 h-5 mx-auto mb-1" />
                    <div className="text-xs font-semibold">{r.label}</div>
                  </button>
                );
              })}
            </div>
            <p className="text-xs text-navy-400 mt-1.5">{roleCards.find((r) => r.role === selectedRole)?.desc}</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'register' && (
              <div>
                <label className="label-text">Full Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter your full name"
                  className="input-field"
                />
              </div>
            )}

            <div>
              <label className="label-text">College Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-navy-400" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your.name@nift.edu.in"
                  className="input-field pl-10"
                />
              </div>
            </div>

            {mode === 'register' && (
              <div>
                <label className="label-text">Department</label>
                <select
                  required
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  className="input-field"
                >
                  <option value="">Select department</option>
                  <option>Computer Science & Engineering</option>
                  <option>Electronics & Communication</option>
                  <option>Mechanical Engineering</option>
                  <option>Civil Engineering</option>
                  <option>Information Technology</option>
                  <option>Business Administration</option>
                </select>
              </div>
            )}

            <div>
              <label className="label-text">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-navy-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="input-field pl-10 pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-navy-400 hover:text-navy-600"
                >
                  {showPassword ? <EyeOff className="w-4.5 h-4.5" /> : <Eye className="w-4.5 h-4.5" />}
                </button>
              </div>
            </div>

            {mode === 'login' && (
              <div className="flex items-center justify-between text-sm">
                <label className="flex items-center gap-2 text-navy-600 cursor-pointer">
                  <input type="checkbox" className="rounded border-navy-300 text-primary-600" />
                  Remember me
                </label>
                <button type="button" className="text-primary-600 hover:text-primary-700 font-medium">Forgot password?</button>
              </div>
            )}

            <button type="submit" className="btn-primary w-full !py-3 text-base">
              {mode === 'login' ? 'Sign In' : 'Create Account'}
              <ArrowRight className="w-4.5 h-4.5" />
            </button>
          </form>

          <div className="mt-6 text-center text-sm text-navy-500">
            {mode === 'login' ? (
              <>
                Don't have an account?{' '}
                <button onClick={() => setMode('register')} className="text-primary-600 hover:text-primary-700 font-semibold">
                  Register here
                </button>
              </>
            ) : (
              <>
                Already have an account?{' '}
                <button onClick={() => setMode('login')} className="text-primary-600 hover:text-primary-700 font-semibold">
                  Sign in
                </button>
              </>
            )}
          </div>

          <div className="mt-6 p-3 bg-primary-50 rounded-lg border border-primary-100 text-center">
            <p className="text-xs text-primary-700">
              <strong>Demo Mode:</strong> Select a role and click Sign In to explore the platform with sample data.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
