import { useApp } from '@/context/AppContext';
import { formatRelativeTime, formatDate, daysUntil } from '@/data/mockData';
import { priorityConfig, categoryConfig } from '@/lib/uiConfig';
import { Megaphone, Eye, CheckCircle2, Clock, Paperclip, FilePlus2, Search, Target } from 'lucide-react';
import { useState } from 'react';

export default function MyAnnouncements() {
  const { announcements, user, setScreen } = useApp();
  const [search, setSearch] = useState('');

  const myAnnouncements = announcements.filter(
    (a) => a.publishedBy === user.name || a.publishedByRole === 'faculty'
  );

  const filtered = myAnnouncements.filter((a) => {
    if (!search) return true;
    const q = search.toLowerCase();
    return a.title.toLowerCase().includes(q) || a.summary.toLowerCase().includes(q);
  });

  return (
    <div className="animate-fade-in">
      <div className="flex items-center justify-between mb-5 flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-navy-900 mb-1 flex items-center gap-2">
            <Megaphone className="w-6 h-6 text-primary-600" />
            My Announcements
          </h1>
          <p className="text-navy-500 text-sm">{myAnnouncements.length} notices published by you.</p>
        </div>
        <button onClick={() => setScreen('faculty-create')} className="btn-primary">
          <FilePlus2 className="w-4 h-4" />
          New Announcement
        </button>
      </div>

      <div className="relative mb-4 max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-navy-400" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search your announcements..."
          className="input-field pl-10"
        />
      </div>

      {filtered.length === 0 ? (
        <div className="card p-12 text-center">
          <div className="w-16 h-16 bg-navy-100 rounded-full flex items-center justify-center mx-auto mb-3">
            <Megaphone className="w-8 h-8 text-navy-400" />
          </div>
          <h3 className="font-semibold text-navy-800 mb-1">No announcements yet</h3>
          <p className="text-sm text-navy-500 mb-4">Start by creating your first announcement.</p>
          <button onClick={() => setScreen('faculty-create')} className="btn-primary">
            <FilePlus2 className="w-4 h-4" />
            Create Announcement
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((a) => {
            const cat = categoryConfig[a.category];
            const pri = priorityConfig[a.priority];
            const ackRate = a.totalRecipients ? Math.round((a.acknowledged || 0) / a.totalRecipients * 100) : 0;
            const daysLeft = a.deadline ? daysUntil(a.deadline) : null;

            return (
              <div key={a.id} className="card p-5 hover:shadow-card-hover transition-all">
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className={`badge ${cat.classes}`}>{a.category}</span>
                    <span className={`badge ${pri.classes}`}>{pri.label}</span>
                    {a.hasAttachment && (
                      <span className="badge bg-navy-100 text-navy-600">
                        <Paperclip className="w-3 h-3" /> Attachment
                      </span>
                    )}
                  </div>
                  <span className="text-xs text-navy-400 flex-shrink-0">{formatRelativeTime(a.publishedDate)}</span>
                </div>

                <h3 className="font-bold text-navy-900 mb-1">{a.title}</h3>
                <p className="text-sm text-navy-500 mb-3 line-clamp-2">{a.summary}</p>

                <div className="flex items-center justify-between flex-wrap gap-3 pt-3 border-t border-navy-100">
                  <div className="flex items-center gap-4 text-xs text-navy-500">
                    <span className="flex items-center gap-1">
                      <Target className="w-3.5 h-3.5" /> {a.targetDepartments.length} dept(s) • Sem {a.targetSemesters.join(', ')}
                    </span>
                    {daysLeft !== null && daysLeft >= 0 && (
                      <span className="flex items-center gap-1 font-medium text-warning-600">
                        <Clock className="w-3.5 h-3.5" /> Deadline: {formatDate(a.deadline!)}
                      </span>
                    )}
                  </div>
                  {a.totalRecipients && (
                    <div className="flex items-center gap-3">
                      <span className="text-xs text-navy-500 flex items-center gap-1">
                        <Eye className="w-3.5 h-3.5" /> {a.acknowledged}/{a.totalRecipients}
                      </span>
                      <div className="w-24 h-1.5 bg-navy-100 rounded-full overflow-hidden">
                        <div className="h-full bg-primary-600 rounded-full" style={{ width: `${ackRate}%` }} />
                      </div>
                      <span className="text-xs font-semibold text-navy-700">{ackRate}%</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
