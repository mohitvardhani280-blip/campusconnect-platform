import { useApp } from '@/context/AppContext';
import { announcements, formatDate, formatRelativeTime, daysUntil } from '@/data/mockData';
import { priorityConfig, categoryConfig } from '@/lib/uiConfig';
import {
  Megaphone,
  FilePlus2,
  Users,
  CheckCircle2,
  TrendingUp,
  Clock,
  Paperclip,
  ArrowRight,
  Eye,
} from 'lucide-react';
import type { ScreenType } from '@/types';

export default function FacultyDashboard() {
  const { user, setScreen, announcements: allAnnouncements } = useApp();

  const myAnnouncements = allAnnouncements.filter((a) => a.publishedBy === user.name || a.publishedByRole === 'faculty');
  const recentMine = myAnnouncements.slice(0, 4);

  const stats = [
    { label: 'Published Notices', value: myAnnouncements.length, icon: Megaphone, color: 'bg-primary-100 text-primary-700' },
    { label: 'Total Reach', value: myAnnouncements.reduce((sum, a) => sum + (a.totalRecipients || 0), 0), icon: Users, color: 'bg-accent-100 text-accent-700' },
    { label: 'Avg. Acknowledgement', value: Math.round(myAnnouncements.reduce((sum, a) => {
      const rate = a.totalRecipients ? (a.acknowledged || 0) / a.totalRecipients * 100 : 0;
      return sum + rate;
    }, 0) / (myAnnouncements.length || 1)) + '%', icon: CheckCircle2, color: 'bg-success-100 text-success-700' },
    { label: 'Active Deadlines', value: myAnnouncements.filter((a) => a.deadline && daysUntil(a.deadline) >= 0).length, icon: Clock, color: 'bg-warning-100 text-warning-700' },
  ];

  const goToScreen = (s: ScreenType) => setScreen(s);

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Welcome */}
      <div className="relative overflow-hidden bg-gradient-to-r from-navy-900 to-navy-800 rounded-xl p-6 text-white">
        <div className="absolute top-0 right-0 w-64 h-64 bg-primary-600/20 rounded-full blur-3xl -mr-20 -mt-20" />
        <div className="relative z-10">
          <h1 className="text-2xl font-bold mb-1">Welcome, {user.name}!</h1>
          <p className="text-navy-300 text-sm">{user.designation} • {user.department} • Employee ID: {user.employeeId}</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.label} className="card p-4">
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-2 ${s.color}`}>
                <Icon className="w-5 h-5" />
              </div>
              <div className="text-2xl font-bold text-navy-900">{s.value}</div>
              <div className="text-xs text-navy-500">{s.label}</div>
            </div>
          );
        })}
      </div>

      {/* Quick action */}
      <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-primary-50 to-accent-50 rounded-xl border border-primary-100">
        <div className="w-10 h-10 bg-primary-600 rounded-lg flex items-center justify-center flex-shrink-0">
          <FilePlus2 className="w-5 h-5 text-white" />
        </div>
        <div className="flex-1">
          <p className="text-sm font-semibold text-navy-800">Create a New Announcement</p>
          <p className="text-xs text-navy-600">Publish notices to specific departments, semesters, or classes with deadlines and priority levels.</p>
        </div>
        <button onClick={() => goToScreen('faculty-create')} className="btn-primary !py-2">
          <FilePlus2 className="w-4 h-4" />
          <span className="hidden sm:inline">New Notice</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* My recent announcements */}
        <div className="lg:col-span-2">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-bold text-navy-900">My Recent Announcements</h2>
            <button onClick={() => goToScreen('faculty-my-announcements')} className="text-sm text-primary-600 font-medium hover:text-primary-700 flex items-center gap-1">
              View all <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="space-y-3">
            {recentMine.map((a) => {
              const cat = categoryConfig[a.category];
              const pri = priorityConfig[a.priority];
              const ackRate = a.totalRecipients ? Math.round((a.acknowledged || 0) / a.totalRecipients * 100) : 0;
              return (
                <div key={a.id} className="card p-4 hover:shadow-card-hover transition-all">
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div className="flex items-center gap-2">
                      <span className={`badge ${cat.classes}`}>{a.category}</span>
                      <span className={`badge ${pri.classes}`}>{pri.label}</span>
                    </div>
                    <span className="text-xs text-navy-400">{formatRelativeTime(a.publishedDate)}</span>
                  </div>
                  <h3 className="font-semibold text-navy-900 text-sm mb-1">{a.title}</h3>
                  <p className="text-xs text-navy-500 line-clamp-2 mb-3">{a.summary}</p>
                  {a.totalRecipients && (
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs text-navy-500 flex items-center gap-1">
                          <Eye className="w-3.5 h-3.5" /> Acknowledgement: {a.acknowledged}/{a.totalRecipients}
                        </span>
                        <span className="text-xs font-semibold text-navy-700">{ackRate}%</span>
                      </div>
                      <div className="h-1.5 bg-navy-100 rounded-full overflow-hidden">
                        <div className="h-full bg-primary-600 rounded-full" style={{ width: `${ackRate}%` }} />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Right column */}
        <div className="space-y-5">
          {/* Quick tips */}
          <div className="card p-4">
            <h3 className="font-bold text-navy-900 mb-3 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-accent-600" />
              Tips for Better Reach
            </h3>
            <div className="space-y-2 text-sm text-navy-600">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-success-500 flex-shrink-0 mt-0.5" />
                <span>Set urgent priority for deadline-sensitive notices</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-success-500 flex-shrink-0 mt-0.5" />
                <span>Attach documents for assignments and circulars</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-success-500 flex-shrink-0 mt-0.5" />
                <span>Target specific departments to avoid notification fatigue</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-success-500 flex-shrink-0 mt-0.5" />
                <span>Use tags to make notices easily searchable</span>
              </div>
            </div>
          </div>

          {/* Pending acknowledgements */}
          <div className="card p-4">
            <h3 className="font-bold text-navy-900 mb-3">Needs Attention</h3>
            <div className="space-y-2">
              {myAnnouncements.filter((a) => a.totalRecipients && a.acknowledged !== undefined && a.acknowledged < a.totalRecipients * 0.5).map((a) => (
                <div key={a.id} className="p-3 bg-warning-50 rounded-lg border border-warning-100">
                  <p className="text-sm font-medium text-navy-800">{a.title}</p>
                  <p className="text-xs text-warning-700 mt-1">Low acknowledgement rate — only {Math.round((a.acknowledged! / a.totalRecipients!) * 100)}% of students have read this</p>
                </div>
              ))}
              {myAnnouncements.filter((a) => a.totalRecipients && a.acknowledged !== undefined && a.acknowledged < a.totalRecipients * 0.5).length === 0 && (
                <p className="text-sm text-navy-400">All notices have good engagement.</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
